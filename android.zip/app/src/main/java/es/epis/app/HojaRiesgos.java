package es.epis.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.ArrayList;
import java.util.List;

/**
 * Dibuja el Mod. 304 (Información y consulta de riesgos y medidas preventivas) en A4 apaisado,
 * 842 x 595 puntos. Las medidas copian las del Word original de Azvi. 9 trabajadores por hoja.
 */
public class HojaRiesgos {

    public static final int ANCHO = 842, ALTO = 595;
    public static final int FILAS = 9;

    private static final float X0 = 38.1f, X1 = 803.8f;
    private static final float[] COLS = {X0, 94.8f, 307.2f, 420.9f, 583.8f, 697.2f, X1};
    private static final float FILA_Y0 = 206.4f, ALTO_FILA = 30f;

    public static final String PIE = "Mod. 304, ES. 02/19, Rev. 4";
    public static final String TEXTO =
            "Se ha informado y consultado de los riesgos para la seguridad y la salud de los trabajadores, tanto de carácter "
            + "general como los específicos de cada puesto de trabajo del personal referenciado, de las medidas preventivas "
            + "aplicables a los riesgos señalados, de las medidas de emergencia y de las condiciones de trabajo.";
    private static final String NOTA1 = "NOTA 1: El Plan de Seguridad y Salud/Documento de Gestión Preventiva queda a disposición de los trabajadores.";
    private static final String NOTA2 = "NOTA 2: Si tiene cualquier consulta en SST diríjase a la Jefatura de obra o al Responsable de Prevención.";
    private static final String AYUDA_OBS = "A rellenar en caso de aportaciones, comentarios y aclaraciones, de especial relevancia, "
            + "por parte de los trabajadores. Enviar copia a la Dirección de Calidad, Prevención y MA en caso necesario.";

    /** Un trabajador que ha firmado. */
    public static class Fila {
        public String fecha = "", nombre = "", dni = "", puesto = "", empresa = "AZVI";
        public Bitmap firma;
    }

    /** Lo común a todas las hojas. */
    public static class Datos {
        public String obra = "", numeroObra = "", observaciones = "", elaborado = "";
        public Bitmap firmaTecnico;
        public List<Fila> filas = new ArrayList<>();
    }

    public static int hojas(Datos d) {
        return Math.max(1, (d.filas.size() + FILAS - 1) / FILAS);
    }

    private final Bitmap logo;
    private final Typeface normal, negrita;
    private final Paint linea, texto;

    public HojaRiesgos(Bitmap logo, Typeface normal, Typeface negrita) {
        this.logo = logo;
        this.normal = normal;
        this.negrita = negrita;
        linea = new Paint();
        linea.setColor(Color.BLACK);
        linea.setStyle(Paint.Style.STROKE);
        linea.setStrokeWidth(0.75f);
        linea.setAntiAlias(true);
        texto = new Paint();
        texto.setColor(Color.BLACK);
        texto.setAntiAlias(true);
        texto.setFilterBitmap(true);
    }

    /** Dibuja la hoja número {@code hoja} (empieza en 0). */
    public void dibujar(Canvas c, Datos d, int hoja) {
        int total = hojas(d);

        // --- Cabecera ---
        caja(c, 51.4f, 93.4f);
        c.drawLine(187.0f, 51.4f, 187.0f, 93.4f, linea);
        c.drawLine(676.0f, 51.4f, 676.0f, 93.4f, linea);
        if (logo != null) imagen(c, logo, new RectF(72.15f, 60.9f, 157.2f, 83.6f));
        fuente(12f, true);
        centrado(c, "INFORMACIÓN Y CONSULTA DE RIESGOS Y MEDIDAS PREVENTIVAS", 187.0f, 676.0f, 77f);
        fuente(12f, false);
        c.drawText("Hoja:", 682.0f, 77f, texto);
        centrado(c, String.valueOf(hoja + 1), 707.3f, 739.9f, 77f);
        c.drawText("de", 739.9f, 77f, texto);
        centrado(c, String.valueOf(total), 752.1f, 798f, 77f);

        // --- Obra ---
        caja(c, 93.4f, 116.5f);
        fuente(12f, false);
        String obra = "Obra: " + d.obra;
        float tam = 12f;
        while (tam > 7 && texto.measureText(obra) > 669.2f - 45.5f - 8) { tam -= 0.25f; fuente(tam, false); }
        c.drawText(obra, 45.5f, 109.6f, texto);
        fuente(12f, false);
        c.drawText("Nº obra: " + d.numeroObra, 669.2f, 109.6f, texto);

        // --- Texto ---
        caja(c, 116.5f, 173.0f);
        parrafo(c, TEXTO, 42.8f, 792.0f, 134.8f, 12f, 14.65f);

        // --- Tabla ---
        caja(c, 173.0f, 189.7f);
        fuente(10f, false);
        centrado(c, "PERSONAL QUE HA SIDO CONSULTADO E INFORMADO", X0, X1, 185.2f);
        float yFin = FILA_Y0 + FILAS * ALTO_FILA;
        c.drawRect(X0, 189.7f, X1, yFin, linea);
        c.drawLine(X0, FILA_Y0, X1, FILA_Y0, linea);
        for (int i = 1; i < FILAS; i++) c.drawLine(X0, FILA_Y0 + i * ALTO_FILA, X1, FILA_Y0 + i * ALTO_FILA, linea);
        for (int i = 1; i < COLS.length - 1; i++) c.drawLine(COLS[i], 189.7f, COLS[i], yFin, linea);
        String[] titulos = {"FECHA", "NOMBRE Y APELLIDOS", "D.N.I.", "PUESTO TRABAJO", "EMPRESA", "FIRMA"};
        for (int i = 0; i < titulos.length; i++) centrado(c, titulos[i], COLS[i], COLS[i + 1], 201.9f);

        for (int i = 0; i < FILAS; i++) {
            int k = hoja * FILAS + i;
            if (k >= d.filas.size()) break;
            Fila f = d.filas.get(k);
            float y = FILA_Y0 + i * ALTO_FILA, base = y + 19f;
            celda(c, f.fecha, 0, base, true);
            celda(c, f.nombre, 1, base, false);
            celda(c, f.dni, 2, base, true);
            celda(c, f.puesto, 3, base, true);
            celda(c, f.empresa, 4, base, true);
            if (f.firma != null) imagen(c, f.firma, new RectF(COLS[5] + 3, y + 2, COLS[6] - 3, y + ALTO_FILA - 2));
        }

        // --- Pie: notas, observaciones y elaborado por ---
        c.drawRect(X0, yFin, X1, 554.7f, linea);
        c.drawLine(COLS[2], yFin, COLS[2], 554.7f, linea);
        c.drawLine(COLS[4], yFin, COLS[4], 554.7f, linea);
        float yn = parrafo(c, NOTA1, 42.8f, 303.2f, 489.6f, 10f, 12.2f);
        parrafo(c, NOTA2, 42.8f, 303.2f, yn + 15.2f, 10f, 12.2f);

        fuente(10f, false);
        c.drawText("Observaciones:", 311.8f, 489.6f, texto);
        if (!d.observaciones.isEmpty()) {
            fuente(9.5f, false);
            List<String> l = partir(d.observaciones.replace('\n', ' '), 578.8f - 311.8f);
            for (int i = 0; i < l.size() && i < 3; i++) c.drawText(l.get(i), 311.8f, 501.5f + i * 10.5f, texto);
        }
        parrafo(c, AYUDA_OBS, 311.8f, 578.8f, 533.1f, 8f, 9.75f);

        fuente(12f, false);
        c.drawText("Elaborado por:", 588.5f, 489.6f, texto);
        float an = texto.measureText("Elaborado por: ");
        tam = 11f;
        fuente(tam, false);
        while (tam > 7 && texto.measureText(d.elaborado) > 800f - 588.5f - an) { tam -= 0.25f; fuente(tam, false); }
        c.drawText(d.elaborado, 588.5f + an, 489.6f, texto);
        fuente(12f, false);
        c.drawText("Firma", 588.5f, 538.9f, texto);
        if (d.firmaTecnico != null) imagen(c, d.firmaTecnico, new RectF(622f, 496f, 798f, 552f));

        fuente(8f, false);
        c.drawText(PIE, 803.7f - texto.measureText(PIE), 570.8f, texto);
    }

    // ======================================================================
    private void celda(Canvas c, String s, int col, float base, boolean centrar) {
        if (s == null || s.isEmpty()) return;
        float ancho = COLS[col + 1] - COLS[col] - 6;
        float tam = 10.5f;
        fuente(tam, false);
        while (tam > 6 && texto.measureText(s) > ancho) { tam -= 0.25f; fuente(tam, false); }
        if (centrar) centrado(c, s, COLS[col], COLS[col + 1], base);
        else c.drawText(s, COLS[col] + 4, base, texto);
    }

    private void imagen(Canvas c, Bitmap b, RectF hueco) {
        float esc = Math.min(hueco.width() / b.getWidth(), hueco.height() / b.getHeight());
        float w = b.getWidth() * esc, h = b.getHeight() * esc;
        float x = hueco.left + (hueco.width() - w) / 2, y = hueco.top + (hueco.height() - h) / 2;
        c.drawBitmap(b, new Rect(0, 0, b.getWidth(), b.getHeight()), new RectF(x, y, x + w, y + h), texto);
    }

    private void caja(Canvas c, float y0, float y1) {
        c.drawRect(X0, y0, X1, y1, linea);
    }

    private void fuente(float tam, boolean enNegrita) {
        texto.setTextSize(tam);
        texto.setTypeface(enNegrita ? negrita : normal);
    }

    private void centrado(Canvas c, String s, float xa, float xb, float yb) {
        c.drawText(s, (xa + xb - texto.measureText(s)) / 2, yb, texto);
    }

    private List<String> partir(String s, float ancho) {
        List<String> lineas = new ArrayList<>();
        StringBuilder actual = new StringBuilder();
        for (String palabra : s.split(" ")) {
            if (palabra.isEmpty()) continue;
            String prueba = actual.length() == 0 ? palabra : actual + " " + palabra;
            if (texto.measureText(prueba) <= ancho || actual.length() == 0) {
                actual.setLength(0);
                actual.append(prueba);
            } else {
                lineas.add(actual.toString());
                actual.setLength(0);
                actual.append(palabra);
            }
        }
        if (actual.length() > 0) lineas.add(actual.toString());
        return lineas;
    }

    /** Párrafo justificado. Devuelve la línea base de la última línea. */
    private float parrafo(Canvas c, String s, float xa, float xb, float yb, float tam, float interl) {
        fuente(tam, false);
        List<String> lineas = partir(s, xb - xa);
        float y = yb;
        for (int i = 0; i < lineas.size(); i++) {
            y = yb + i * interl;
            String l = lineas.get(i);
            String[] pal = l.split(" ");
            if (i == lineas.size() - 1 || pal.length == 1) {
                c.drawText(l, xa, y, texto);
                continue;
            }
            float suma = 0;
            for (String p : pal) suma += texto.measureText(p);
            float hueco = (xb - xa - suma) / (pal.length - 1);
            float x = xa;
            for (String p : pal) {
                c.drawText(p, x, y, texto);
                x += texto.measureText(p) + hueco;
            }
        }
        return y;
    }
}
