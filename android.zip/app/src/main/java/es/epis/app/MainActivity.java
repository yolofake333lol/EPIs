package es.epis.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    // ---- Configuración ----
    private static final String CLAVE = "c666ad36462926e02c8c2ceb";   // la misma que en el script de Google
    private static final String OBRA_INICIAL = "MTO. Y CONSERVACIÓN VÍAS FÉRREAS ARCELOR MITTAL ASTURIAS";
    private static final String EPIS_INICIALES =
            "Casco de seguridad con barbuquejo\n"
            + "Traje de agua alta visibilidad\n"
            + "Botas de seguridad\n"
            + "Polar alta visibilidad\n"
            + "Camisa alta visibilidad\n"
            + "Guantes de cuero\n"
            + "Chaqueton de invierno\n"
            + "Pantalón alta visibilidad\n"
            + "\n"
            + "Gafas antiproyecciones\n"
            + "Candado personal de seguridad";

    // ---- Colores (los mismos que la app de fichajes) ----
    private static final int AZUL = Color.parseColor("#1A4D8F");
    private static final int FONDO = Color.parseColor("#EEF2F6");
    private static final int TEXTO = Color.parseColor("#14202E");
    private static final int BORDE = Color.parseColor("#C9D3DE");
    private static final int GRIS = Color.parseColor("#5B6B7C");
    private static final int VERDE = Color.parseColor("#2E7D32");
    private static final int NARANJA = Color.parseColor("#E07B00");
    private static final int TINTA = Color.parseColor("#0B1F5C");

    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean enviando = false;

    private FrameLayout raiz;
    private LinearLayout pantallaEntrega, pantallaAjustes, pantallaHistorial;
    private LinearLayout listaEpis, listaHistorial, listaTrabajadores;
    private TextView cabeceraEntrega, avisoPendientes;
    private AutoCompleteTextView campoNombre;
    private EditText campoCorreo, campoOtros;
    private final List<CheckBox> casillas = new ArrayList<>();
    private Firma firma;
    private EditText ajUrl, ajObra, ajNumero, ajEpis;

    // ======================================================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("datos", MODE_PRIVATE);
        if (!prefs.contains("epis")) {
            prefs.edit().putString("epis", EPIS_INICIALES).putString("obra", OBRA_INICIAL).apply();
        }

        raiz = new FrameLayout(this);
        raiz.setBackgroundColor(FONDO);
        crearPantallaEntrega();
        crearPantallaAjustes();
        crearPantallaHistorial();
        setContentView(raiz);
        mostrar(pantallaEntrega);
    }

    @Override
    protected void onResume() {
        super.onResume();
        pintarAvisoPendientes();
        reintentarPendientes(false);
    }

    @Override
    public void onBackPressed() {
        if (pantallaEntrega.getVisibility() != View.VISIBLE) mostrar(pantallaEntrega);
        else super.onBackPressed();
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void mostrar(View pantalla) {
        ocultarTeclado();
        pantallaEntrega.setVisibility(pantalla == pantallaEntrega ? View.VISIBLE : View.GONE);
        pantallaAjustes.setVisibility(pantalla == pantallaAjustes ? View.VISIBLE : View.GONE);
        pantallaHistorial.setVisibility(pantalla == pantallaHistorial ? View.VISIBLE : View.GONE);
        if (pantalla == pantallaEntrega) { pintarCabecera(); pintarEpis(); pintarAvisoPendientes(); }
        if (pantalla == pantallaAjustes) cargarAjustes();
        if (pantalla == pantallaHistorial) pintarHistorial();
    }

    private void ocultarTeclado() {
        View v = getCurrentFocus();
        if (v != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
            v.clearFocus();
        }
    }

    // ======================================================================
    // Piezas de la interfaz
    // ======================================================================
    private LinearLayout pantalla(String titulo, boolean conVolver, View... botones) {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);

        LinearLayout barra = new LinearLayout(this);
        barra.setBackgroundColor(Color.WHITE);
        barra.setGravity(Gravity.CENTER_VERTICAL);
        barra.setPadding(dp(12), dp(6), dp(6), dp(6));
        if (conVolver) {
            TextView volver = botonIcono("←");
            volver.setOnClickListener(v -> mostrar(pantallaEntrega));
            barra.addView(volver, new LinearLayout.LayoutParams(dp(48), dp(48)));
        } else {
            ImageView logo = new ImageView(this);
            logo.setImageResource(R.drawable.logo_azvi);
            logo.setAdjustViewBounds(true);
            barra.addView(logo, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28)));
        }
        TextView t = new TextView(this);
        t.setText(titulo);
        t.setTextColor(AZUL);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(12), 0, 0, 0);
        barra.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        for (View b : botones) barra.addView(b, new LinearLayout.LayoutParams(dp(48), dp(48)));
        p.addView(barra);
        View linea = new View(this);
        linea.setBackgroundColor(AZUL);
        p.addView(linea, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));
        raiz.addView(p, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return p;
    }

    private TextView botonIcono(String icono) {
        TextView b = new TextView(this);
        b.setText(icono);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        b.setTextColor(GRIS);
        b.setGravity(Gravity.CENTER);
        b.setClickable(true);
        return b;
    }

    /** Zona desplazable con un contenedor vertical dentro. */
    private LinearLayout contenido(LinearLayout pantalla) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(10), dp(14), dp(30));
        sv.addView(c, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pantalla.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return c;
    }

    private LinearLayout tarjeta(LinearLayout padre, String titulo) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(14), dp(12), dp(14), dp(14));
        t.setBackground(fondo(Color.WHITE, BORDE, 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        padre.addView(t, lp);
        if (titulo != null) {
            TextView tt = new TextView(this);
            tt.setText(titulo);
            tt.setTextColor(AZUL);
            tt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            tt.setTypeface(Typeface.DEFAULT_BOLD);
            tt.setPadding(0, 0, 0, dp(6));
            t.addView(tt);
        }
        return t;
    }

    private GradientDrawable fondo(int color, int borde, int radio) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radio));
        if (borde != 0) g.setStroke(dp(1), borde);
        return g;
    }

    private TextView etiqueta(LinearLayout padre, String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(GRIS);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setPadding(0, dp(8), 0, dp(2));
        padre.addView(t);
        return t;
    }

    private EditText campo(LinearLayout padre, String pista, int tipo) {
        EditText e = new EditText(this);
        prepararCampo(e, pista, tipo);
        padre.addView(e, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }

    private void prepararCampo(EditText e, String pista, int tipo) {
        e.setHint(pista);
        e.setInputType(tipo);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        e.setTextColor(TEXTO);
        e.setHintTextColor(BORDE);
        e.setPadding(dp(12), dp(12), dp(12), dp(12));
        e.setBackground(fondo(Color.parseColor("#F7F9FB"), BORDE, 8));
    }

    private Button boton(String texto, int color, boolean relleno) {
        Button b = new Button(this);
        b.setText(texto);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, relleno ? 20 : 16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(relleno ? Color.WHITE : color);
        b.setBackground(fondo(relleno ? color : Color.WHITE, relleno ? 0 : color, 10));
        b.setPadding(dp(16), dp(10), dp(16), dp(10));
        return b;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private void aviso(String titulo, String texto) {
        new AlertDialog.Builder(this).setTitle(titulo).setMessage(texto).setPositiveButton("Vale", null).show();
    }

    // ======================================================================
    // Pantalla principal: nueva entrega
    // ======================================================================
    private void crearPantallaEntrega() {
        TextView historial = botonIcono("☰");
        historial.setOnClickListener(v -> mostrar(pantallaHistorial));
        TextView ajustes = botonIcono("⚙");
        ajustes.setOnClickListener(v -> mostrar(pantallaAjustes));
        pantallaEntrega = pantalla("Entrega de EPIs", false, historial, ajustes);
        LinearLayout c = contenido(pantallaEntrega);

        avisoPendientes = new TextView(this);
        avisoPendientes.setTextColor(Color.WHITE);
        avisoPendientes.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        avisoPendientes.setTypeface(Typeface.DEFAULT_BOLD);
        avisoPendientes.setPadding(dp(14), dp(12), dp(14), dp(12));
        avisoPendientes.setBackground(fondo(NARANJA, 0, 10));
        avisoPendientes.setOnClickListener(v -> reintentarPendientes(true));
        c.addView(avisoPendientes);

        cabeceraEntrega = new TextView(this);
        cabeceraEntrega.setTextColor(TEXTO);
        cabeceraEntrega.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        cabeceraEntrega.setPadding(dp(4), dp(10), 0, 0);
        c.addView(cabeceraEntrega);

        // --- Trabajador ---
        LinearLayout t = tarjeta(c, "Trabajador");
        etiqueta(t, "Nombre y apellidos");
        campoNombre = new AutoCompleteTextView(this);
        prepararCampo(campoNombre, "Escribe el nombre", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        campoNombre.setThreshold(1);
        t.addView(campoNombre, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        campoNombre.setOnItemClickListener((parent, view, pos, id) -> {
            String correo = correoDe(campoNombre.getText().toString());
            if (correo != null) campoCorreo.setText(correo);
            ocultarTeclado();
        });
        campoNombre.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int d) { }
            public void onTextChanged(CharSequence s, int a, int b, int d) { }
            public void afterTextChanged(Editable s) {
                String correo = correoDe(s.toString());
                if (correo != null && campoCorreo.getText().length() == 0) campoCorreo.setText(correo);
            }
        });
        etiqueta(t, "Correo del trabajador");
        campoCorreo = campo(t, "nombre@correo.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);

        // --- EPIs ---
        LinearLayout e = tarjeta(c, "EPIs que se entregan");
        listaEpis = new LinearLayout(this);
        listaEpis.setOrientation(LinearLayout.VERTICAL);
        e.addView(listaEpis);
        etiqueta(e, "Otros (separados por comas)");
        campoOtros = campo(e, "Ej.: Tapones auditivos", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);

        // --- Firma ---
        LinearLayout f = tarjeta(c, "Firma del trabajador");
        firma = new Firma(this);
        firma.setBackground(fondo(Color.WHITE, BORDE, 8));
        f.addView(firma, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230)));
        Button borrar = boton("Borrar firma", GRIS, false);
        borrar.setOnClickListener(v -> firma.borrar());
        LinearLayout.LayoutParams lpb = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpb.gravity = Gravity.END;
        lpb.topMargin = dp(8);
        f.addView(borrar, lpb);

        Button enviar = boton("Generar y enviar", AZUL, true);
        enviar.setOnClickListener(v -> comprobarYEnviar());
        LinearLayout.LayoutParams lpe = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64));
        lpe.topMargin = dp(16);
        c.addView(enviar, lpe);
    }

    private void pintarCabecera() {
        cabeceraEntrega.setText("Nº " + prefs.getInt("siguiente", 1) + "   ·   " + hoy());
        List<String> nombres = new ArrayList<>();
        JSONArray tr = leerLista("trabajadores");
        for (int i = 0; i < tr.length(); i++) nombres.add(tr.optJSONObject(i).optString("nombre"));
        campoNombre.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, nombres));
    }

    private void pintarEpis() {
        // Conserva lo que ya estuviera marcado si se vuelve de otra pantalla
        List<String> marcadas = new ArrayList<>();
        for (CheckBox cb : casillas) if (cb.isChecked()) marcadas.add(cb.getText().toString());
        listaEpis.removeAllViews();
        casillas.clear();
        for (String epi : episConfigurados()) {
            if (epi.trim().isEmpty()) continue;
            CheckBox cb = new CheckBox(this);
            cb.setText(epi.trim());
            cb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            cb.setTextColor(TEXTO);
            cb.setPadding(dp(6), dp(10), 0, dp(10));
            cb.setChecked(marcadas.contains(epi.trim()));
            listaEpis.addView(cb);
            casillas.add(cb);
        }
    }

    private void pintarAvisoPendientes() {
        if (avisoPendientes == null) return;
        int n = 0;
        JSONArray en = leerLista("entregas");
        for (int i = 0; i < en.length(); i++) if (!en.optJSONObject(i).optBoolean("enviado")) n++;
        avisoPendientes.setVisibility(n == 0 ? View.GONE : View.VISIBLE);
        avisoPendientes.setText(n == 1
                ? "⚠  1 entrega sin enviar. Toca aquí para reintentar."
                : "⚠  " + n + " entregas sin enviar. Toca aquí para reintentar.");
    }

    // ======================================================================
    // Generar el documento y enviarlo
    // ======================================================================
    private void comprobarYEnviar() {
        ocultarTeclado();
        final String nombre = campoNombre.getText().toString().trim().replaceAll("\\s+", " ");
        final String correo = campoCorreo.getText().toString().trim();
        final List<String> entregados = new ArrayList<>();
        for (CheckBox cb : casillas) if (cb.isChecked()) entregados.add(cb.getText().toString());
        final List<String> otros = new ArrayList<>();
        for (String o : campoOtros.getText().toString().split(",")) if (!o.trim().isEmpty()) otros.add(o.trim());

        if (nombre.isEmpty()) { aviso("Falta el nombre", "Escribe el nombre del trabajador."); return; }
        if (!correo.isEmpty() && !Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
            aviso("Correo no válido", "Revisa el correo del trabajador."); return;
        }
        if (entregados.isEmpty() && otros.isEmpty()) { aviso("Faltan los EPIs", "Marca al menos un EPI."); return; }
        if (firma.vacia()) { aviso("Falta la firma", "El trabajador tiene que firmar en el recuadro."); return; }

        List<String> todos = new ArrayList<>(entregados);
        todos.addAll(otros);
        StringBuilder resumen = new StringBuilder();
        resumen.append("Nº ").append(prefs.getInt("siguiente", 1)).append(" · ").append(hoy()).append("\n");
        resumen.append(nombre).append("\n");
        resumen.append(correo.isEmpty() ? "Sin correo: solo se enviará a seguridad.\n" : correo + "\n");
        resumen.append("\n");
        for (String s : todos) resumen.append("•  ").append(s).append("\n");

        new AlertDialog.Builder(this)
                .setTitle("¿Generar y enviar?")
                .setMessage(resumen.toString())
                .setPositiveButton("Enviar", (d, w) -> generar(nombre, correo, entregados, otros))
                .setNegativeButton("Revisar", null)
                .show();
    }

    private void generar(String nombre, String correo, List<String> entregados, List<String> otros) {
        int numero = prefs.getInt("siguiente", 1);
        String fecha = hoy();

        HojaEpi.Datos d = new HojaEpi.Datos();
        d.obra = prefs.getString("obra", OBRA_INICIAL);
        d.numero = String.valueOf(numero);
        d.nombre = nombre;
        d.fecha = fecha;
        d.firma = firma.recorte();
        colocarEpis(d, entregados, otros);

        String archivo = "EPI_" + numero + "_" + sinAcentos(nombre).replaceAll("[^A-Za-z0-9]+", "_") + ".pdf";
        File pdf = new File(carpetaEntregas(), archivo);
        try {
            escribirPdf(d, pdf);
        } catch (Exception ex) {
            aviso("Error", "No se ha podido crear el PDF: " + ex.getMessage());
            return;
        }

        List<String> todos = new ArrayList<>(entregados);
        todos.addAll(otros);
        try {
            JSONObject en = new JSONObject();
            en.put("n", numero);
            en.put("fecha", fecha);
            en.put("nombre", nombre);
            en.put("correo", correo);
            en.put("epis", unir(todos, ", "));
            en.put("archivo", archivo);
            en.put("enviado", false);
            JSONArray lista = leerLista("entregas");
            lista.put(en);
            guardarLista("entregas", lista);
        } catch (Exception ignorada) { }

        prefs.edit().putInt("siguiente", numero + 1).apply();
        recordarTrabajador(nombre, correo);
        limpiarFormulario();
        pintarCabecera();
        pintarAvisoPendientes();
        enviarPendiente(numero, true);
    }

    /** Coloca en la hoja todas las filas configuradas y marca las entregadas. Los "otros" ocupan huecos libres. */
    private void colocarEpis(HojaEpi.Datos d, List<String> entregados, List<String> otros) {
        List<String> filas = new ArrayList<>();
        for (String s : episConfigurados()) filas.add(s.trim());
        List<String> pendientes = new ArrayList<>(otros);
        for (int i = 0; i < filas.size() && !pendientes.isEmpty(); i++) {
            if (filas.get(i).isEmpty()) filas.set(i, pendientes.remove(0));
        }
        filas.addAll(pendientes);
        int max = HojaEpi.FILAS * 2;
        // Si no cabe todo, se quitan primero filas vacías y luego EPIs no entregados, empezando por el final
        for (int i = filas.size() - 1; i >= 0 && filas.size() > max; i--) if (filas.get(i).isEmpty()) filas.remove(i);
        for (int i = filas.size() - 1; i >= 0 && filas.size() > max; i--) {
            if (!entregados.contains(filas.get(i)) && !otros.contains(filas.get(i))) filas.remove(i);
        }
        for (String f : filas) {
            d.epis.add(f);
            d.marcados.add(!f.isEmpty() && (entregados.contains(f) || otros.contains(f)));
        }
    }

    private void escribirPdf(HojaEpi.Datos d, File destino) throws Exception {
        Bitmap logo = BitmapFactory.decodeResource(getResources(), R.drawable.logo_azvi);
        Typeface normal = Typeface.createFromAsset(getAssets(), "fuentes/Carlito-Regular.ttf");
        Typeface negrita = Typeface.createFromAsset(getAssets(), "fuentes/Carlito-Bold.ttf");
        HojaEpi hoja = new HojaEpi(logo, normal, negrita);

        PdfDocument doc = new PdfDocument();
        PdfDocument.Page p1 = doc.startPage(new PdfDocument.PageInfo.Builder(HojaEpi.ANCHO, HojaEpi.ALTO, 1).create());
        hoja.dibujarAnverso(p1.getCanvas(), d);
        doc.finishPage(p1);
        PdfDocument.Page p2 = doc.startPage(new PdfDocument.PageInfo.Builder(HojaEpi.ANCHO, HojaEpi.ALTO, 2).create());
        hoja.dibujarReverso(p2.getCanvas());
        doc.finishPage(p2);
        FileOutputStream out = new FileOutputStream(destino);
        try {
            doc.writeTo(out);
        } finally {
            out.close();
            doc.close();
        }
    }

    private void limpiarFormulario() {
        campoNombre.setText("");
        campoCorreo.setText("");
        campoOtros.setText("");
        for (CheckBox cb : casillas) cb.setChecked(false);
        firma.borrar();
    }

    // ---- Envío al script de Google ----

    private void reintentarPendientes(boolean avisar) {
        if (enviando) return;
        JSONArray en = leerLista("entregas");
        List<Integer> nums = new ArrayList<>();
        for (int i = 0; i < en.length(); i++) {
            JSONObject o = en.optJSONObject(i);
            if (!o.optBoolean("enviado")) nums.add(o.optInt("n"));
        }
        if (nums.isEmpty()) return;
        if (prefs.getString("url", "").isEmpty()) {
            if (avisar) aviso("Falta configurar el envío", "Pega la dirección del script de Google en Ajustes (⚙).");
            return;
        }
        if (avisar) toast("Enviando…");
        enviarVarias(nums, 0, 0, avisar);
    }

    private void enviarVarias(final List<Integer> nums, final int i, final int fallos, final boolean avisar) {
        if (i >= nums.size()) {
            pintarAvisoPendientes();
            if (avisar) {
                if (fallos == 0) toast("Enviadas todas las entregas pendientes.");
                else aviso("Sin enviar", fallos + " entrega(s) siguen sin poder enviarse. Comprueba la conexión.");
            }
            return;
        }
        enviar(nums.get(i), error -> enviarVarias(nums, i + 1, fallos + (error == null ? 0 : 1), avisar));
    }

    private void enviarPendiente(final int numero, final boolean avisar) {
        if (prefs.getString("url", "").isEmpty()) {
            aviso("Entrega guardada, sin enviar",
                    "Todavía no está configurado el envío de correos. Pega la dirección del script en Ajustes (⚙) y se enviará.");
            return;
        }
        if (enviando) { toast("Hay otro envío en marcha. Inténtalo en unos segundos."); return; }
        toast("Enviando…");
        enviar(numero, error -> {
            pintarAvisoPendientes();
            if (!avisar) return;
            if (error == null) aviso("Enviado ✔", "El recibí nº " + numero + " se ha enviado al trabajador y a seguridad.");
            else aviso("No se ha podido enviar",
                    "La entrega queda guardada y se reintentará al abrir la app o tocando el aviso naranja.\n\n" + error);
        });
    }

    private interface AlTerminar { void hecho(String error); }

    private void enviar(final int numero, final AlTerminar fin) {
        final JSONObject en = buscarEntrega(numero);
        if (en == null) { fin.hecho("No se encuentra la entrega"); return; }
        final String url = prefs.getString("url", "");
        final File pdf = new File(carpetaEntregas(), en.optString("archivo"));
        enviando = true;
        new Thread(() -> {
            String error;
            try {
                JSONObject cuerpo = new JSONObject();
                cuerpo.put("clave", CLAVE);
                cuerpo.put("correoTrabajador", en.optString("correo"));
                cuerpo.put("asunto", "Entrega de EPIs nº " + numero + " - " + en.optString("nombre") + " - " + en.optString("fecha"));
                cuerpo.put("cuerpo", "Se adjunta el recibí de entrega de equipos de protección individual firmado por "
                        + en.optString("nombre") + " el " + en.optString("fecha") + ".\n\n"
                        + "EPIs entregados:\n- " + en.optString("epis").replace(", ", "\n- ") + "\n\n"
                        + "Documento nº " + numero + ".\n\nAzvi, S.A.");
                cuerpo.put("archivo", en.optString("archivo"));
                cuerpo.put("pdf", android.util.Base64.encodeToString(leerArchivo(pdf), android.util.Base64.NO_WRAP));
                JSONObject r = new JSONObject(post(url, cuerpo.toString()));
                error = r.optBoolean("ok") ? null : r.optString("error", "Respuesta desconocida");
            } catch (Exception ex) {
                error = "Sin conexión o dirección incorrecta (" + ex.getClass().getSimpleName() + ")";
            }
            final String err = error;
            handler.post(() -> {
                enviando = false;
                if (err == null) marcarEnviada(numero);
                fin.hecho(err);
            });
        }).start();
    }

    /** POST al script. Google responde con una redirección que hay que seguir con GET. */
    private static String post(String direccion, String json) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(direccion).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(false);
        c.setDoOutput(true);
        c.setRequestMethod("POST");
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        OutputStream os = c.getOutputStream();
        os.write(json.getBytes("UTF-8"));
        os.close();
        int code = c.getResponseCode();
        if (code >= 300 && code < 400) {
            String destino = c.getHeaderField("Location");
            c.disconnect();
            return get(destino);
        }
        return leer(c);
    }

    private static String get(String direccion) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(direccion).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(true);
        return leer(c);
    }

    private static String leer(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while (in != null && (n = in.read(buf)) > 0) b.write(buf, 0, n);
        if (in != null) in.close();
        c.disconnect();
        String s = b.toString("UTF-8");
        if (code >= 400 || !s.trim().startsWith("{")) throw new Exception("HTTP " + code);
        return s;
    }

    private void marcarEnviada(int numero) {
        JSONArray lista = leerLista("entregas");
        for (int i = 0; i < lista.length(); i++) {
            JSONObject o = lista.optJSONObject(i);
            if (o.optInt("n") == numero) try { o.put("enviado", true); } catch (Exception ignorada) { }
        }
        guardarLista("entregas", lista);
        if (pantallaHistorial.getVisibility() == View.VISIBLE) pintarHistorial();
    }

    private JSONObject buscarEntrega(int numero) {
        JSONArray lista = leerLista("entregas");
        for (int i = lista.length() - 1; i >= 0; i--) {
            JSONObject o = lista.optJSONObject(i);
            if (o.optInt("n") == numero) return o;
        }
        return null;
    }

    // ======================================================================
    // Historial
    // ======================================================================
    private void crearPantallaHistorial() {
        pantallaHistorial = pantalla("Entregas realizadas", true);
        listaHistorial = contenido(pantallaHistorial);
    }

    private void pintarHistorial() {
        listaHistorial.removeAllViews();
        JSONArray lista = leerLista("entregas");
        if (lista.length() == 0) {
            TextView t = new TextView(this);
            t.setText("Todavía no hay entregas.");
            t.setTextColor(GRIS);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
            t.setPadding(dp(6), dp(20), 0, 0);
            listaHistorial.addView(t);
            return;
        }
        for (int i = lista.length() - 1; i >= 0; i--) {
            final JSONObject o = lista.optJSONObject(i);
            LinearLayout t = tarjeta(listaHistorial, null);
            TextView a = new TextView(this);
            a.setText("Nº " + o.optInt("n") + "  ·  " + o.optString("fecha"));
            a.setTextColor(GRIS);
            a.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            t.addView(a);
            TextView b = new TextView(this);
            b.setText(o.optString("nombre"));
            b.setTextColor(TEXTO);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            b.setTypeface(Typeface.DEFAULT_BOLD);
            t.addView(b);
            TextView e = new TextView(this);
            e.setText(o.optString("epis"));
            e.setTextColor(TEXTO);
            e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            t.addView(e);
            TextView s = new TextView(this);
            boolean ok = o.optBoolean("enviado");
            s.setText(ok ? "✔ Enviado" : "⏳ Sin enviar");
            s.setTextColor(ok ? VERDE : NARANJA);
            s.setTypeface(Typeface.DEFAULT_BOLD);
            s.setPadding(0, dp(4), 0, 0);
            t.addView(s);
            t.setOnClickListener(v -> opcionesEntrega(o));
        }
    }

    private void opcionesEntrega(final JSONObject o) {
        final int numero = o.optInt("n");
        String[] op = {"Ver o compartir el PDF", "Volver a enviar por correo", "Borrar del historial"};
        new AlertDialog.Builder(this)
                .setTitle("Nº " + numero + " · " + o.optString("nombre"))
                .setItems(op, (d, w) -> {
                    if (w == 0) verPdf(o.optString("archivo"));
                    else if (w == 1) enviarPendiente(numero, true);
                    else confirmarBorrado(numero, o.optString("archivo"));
                })
                .show();
    }

    private void verPdf(String archivo) {
        File f = new File(carpetaEntregas(), archivo);
        if (!f.exists()) { aviso("No encontrado", "El PDF ya no está en el móvil."); return; }
        Uri uri = Uri.parse("content://" + ProveedorPdf.AUTORIDAD + "/" + Uri.encode(archivo));
        Intent ver = new Intent(Intent.ACTION_VIEW);
        ver.setDataAndType(uri, "application/pdf");
        ver.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent compartir = new Intent(Intent.ACTION_SEND);
        compartir.setType("application/pdf");
        compartir.putExtra(Intent.EXTRA_STREAM, uri);
        compartir.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent elegir = Intent.createChooser(ver, "Abrir el PDF con…");
        elegir.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{compartir});
        try {
            startActivity(elegir);
        } catch (Exception ex) {
            aviso("Sin visor de PDF", "No hay ninguna app para abrir PDFs en el móvil.");
        }
    }

    private void confirmarBorrado(final int numero, final String archivo) {
        new AlertDialog.Builder(this)
                .setTitle("¿Borrar la entrega nº " + numero + "?")
                .setMessage("Se borra del móvil. Los correos ya enviados y la copia de Drive no se tocan.")
                .setPositiveButton("Borrar", (d, w) -> {
                    JSONArray lista = leerLista("entregas"), nueva = new JSONArray();
                    for (int i = 0; i < lista.length(); i++) if (lista.optJSONObject(i).optInt("n") != numero) nueva.put(lista.optJSONObject(i));
                    guardarLista("entregas", nueva);
                    //noinspection ResultOfMethodCallIgnored
                    new File(carpetaEntregas(), archivo).delete();
                    pintarHistorial();
                    pintarAvisoPendientes();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ======================================================================
    // Ajustes
    // ======================================================================
    private void crearPantallaAjustes() {
        pantallaAjustes = pantalla("Ajustes", true);
        LinearLayout c = contenido(pantallaAjustes);

        LinearLayout envio = tarjeta(c, "Envío de correos");
        etiqueta(envio, "Dirección del script de Google (termina en /exec)");
        ajUrl = campo(envio, "https://script.google.com/macros/s/…/exec", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        ajUrl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        Button probar = boton("Comprobar conexión", AZUL, false);
        probar.setOnClickListener(v -> comprobarScript());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        envio.addView(probar, lp);

        LinearLayout hoja = tarjeta(c, "Datos de la hoja");
        etiqueta(hoja, "Obra");
        ajObra = campo(hoja, "Obra", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        ajObra.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        etiqueta(hoja, "Número de la próxima entrega");
        ajNumero = campo(hoja, "Ej.: 2185", InputType.TYPE_CLASS_NUMBER);

        LinearLayout epis = tarjeta(c, "Lista de EPIs");
        TextView ayuda = etiqueta(epis, "Uno por línea, en el orden de la hoja. Los 10 primeros van a la columna izquierda "
                + "y los siguientes a la derecha. Una línea en blanco deja una fila vacía (ahí se escriben los «otros»).");
        ayuda.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        ajEpis = campo(epis, "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        ajEpis.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        ajEpis.setGravity(Gravity.TOP);
        ajEpis.setMinLines(6);

        Button guardar = boton("Guardar ajustes", AZUL, true);
        guardar.setOnClickListener(v -> guardarAjustes());
        LinearLayout.LayoutParams lpg = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        lpg.topMargin = dp(14);
        c.addView(guardar, lpg);

        LinearLayout tr = tarjeta(c, "Trabajadores guardados");
        TextView ay2 = etiqueta(tr, "Se guardan solos al hacer una entrega. Toca uno para cambiar su correo o borrarlo.");
        ay2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        listaTrabajadores = new LinearLayout(this);
        listaTrabajadores.setOrientation(LinearLayout.VERTICAL);
        tr.addView(listaTrabajadores);
    }

    private void cargarAjustes() {
        ajUrl.setText(prefs.getString("url", ""));
        ajObra.setText(prefs.getString("obra", OBRA_INICIAL));
        ajNumero.setText(String.valueOf(prefs.getInt("siguiente", 1)));
        ajEpis.setText(prefs.getString("epis", EPIS_INICIALES));
        pintarTrabajadores();
    }

    private void guardarAjustes() {
        String url = ajUrl.getText().toString().trim();
        int numero;
        try { numero = Integer.parseInt(ajNumero.getText().toString().trim()); }
        catch (Exception ex) { aviso("Número no válido", "Escribe el número de la próxima entrega."); return; }
        String epis = ajEpis.getText().toString().replaceAll("\\s+$", "");
        int filas = epis.isEmpty() ? 0 : epis.split("\n", -1).length;
        if (filas > HojaEpi.FILAS * 2) { aviso("Demasiados EPIs", "La hoja tiene sitio para 20 filas como máximo."); return; }
        if (!url.isEmpty() && !url.startsWith("https://")) { aviso("Dirección no válida", "La dirección debe empezar por https://"); return; }
        prefs.edit()
                .putString("url", url)
                .putString("obra", ajObra.getText().toString().trim())
                .putInt("siguiente", numero)
                .putString("epis", epis)
                .apply();
        toast("Ajustes guardados");
        mostrar(pantallaEntrega);
        reintentarPendientes(false);
    }

    private void comprobarScript() {
        final String url = ajUrl.getText().toString().trim();
        if (url.isEmpty()) { aviso("Falta la dirección", "Pega primero la dirección del script."); return; }
        toast("Comprobando…");
        new Thread(() -> {
            String res;
            try {
                JSONObject r = new JSONObject(get(url));
                res = "epis".equals(r.optString("servicio")) ? null : "La dirección responde, pero no es el script de EPIs.";
            } catch (Exception ex) {
                res = "No responde. Revisa la dirección y que esté implementado con acceso para «Cualquier usuario».";
            }
            final String r2 = res;
            handler.post(() -> {
                if (r2 == null) aviso("Conexión correcta ✔", "El script responde. Pulsa «Guardar ajustes».");
                else aviso("No funciona", r2);
            });
        }).start();
    }

    private void pintarTrabajadores() {
        listaTrabajadores.removeAllViews();
        JSONArray tr = leerLista("trabajadores");
        if (tr.length() == 0) {
            TextView t = new TextView(this);
            t.setText("Todavía no hay ninguno.");
            t.setTextColor(GRIS);
            listaTrabajadores.addView(t);
        }
        for (int i = 0; i < tr.length(); i++) {
            final JSONObject o = tr.optJSONObject(i);
            TextView t = new TextView(this);
            t.setText(o.optString("nombre") + "\n" + (o.optString("correo").isEmpty() ? "(sin correo)" : o.optString("correo")));
            t.setTextColor(TEXTO);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            t.setPadding(dp(4), dp(10), dp(4), dp(10));
            t.setOnClickListener(v -> editarTrabajador(o.optString("nombre"), o.optString("correo")));
            listaTrabajadores.addView(t);
            View sep = new View(this);
            sep.setBackgroundColor(BORDE);
            listaTrabajadores.addView(sep, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        }
    }

    private void editarTrabajador(final String nombre, String correo) {
        final EditText e = new EditText(this);
        prepararCampo(e, "Correo", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        e.setText(correo);
        FrameLayout marco = new FrameLayout(this);
        marco.setPadding(dp(20), dp(8), dp(20), 0);
        marco.addView(e);
        new AlertDialog.Builder(this)
                .setTitle(nombre)
                .setView(marco)
                .setPositiveButton("Guardar", (d, w) -> { cambiarCorreo(nombre, e.getText().toString().trim()); pintarTrabajadores(); })
                .setNeutralButton("Borrar", (d, w) -> { borrarTrabajador(nombre); pintarTrabajadores(); })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ======================================================================
    // Datos guardados
    // ======================================================================
    private List<String> episConfigurados() {
        List<String> l = new ArrayList<>();
        String s = prefs.getString("epis", EPIS_INICIALES);
        if (s.isEmpty()) return l;
        Collections.addAll(l, s.split("\n", -1));
        return l;
    }

    private JSONArray leerLista(String clave) {
        try { return new JSONArray(prefs.getString(clave, "[]")); }
        catch (Exception ex) { return new JSONArray(); }
    }

    private void guardarLista(String clave, JSONArray a) {
        prefs.edit().putString(clave, a.toString()).apply();
    }

    private String correoDe(String nombre) {
        JSONArray tr = leerLista("trabajadores");
        for (int i = 0; i < tr.length(); i++) {
            JSONObject o = tr.optJSONObject(i);
            if (o.optString("nombre").equalsIgnoreCase(nombre.trim())) return o.optString("correo");
        }
        return null;
    }

    /** Guarda o actualiza un trabajador. Un correo vacío no borra el que ya tuviera. */
    private void recordarTrabajador(String nombre, String correo) {
        guardarTrabajador(nombre, correo, false);
    }

    /** Desde Ajustes: el correo se cambia tal cual, aunque quede vacío. */
    private void cambiarCorreo(String nombre, String correo) {
        guardarTrabajador(nombre, correo, true);
    }

    private void guardarTrabajador(String nombre, String correo, boolean forzar) {
        JSONArray tr = leerLista("trabajadores"), nueva = new JSONArray();
        try {
            boolean puesto = false;
            List<JSONObject> l = new ArrayList<>();
            for (int i = 0; i < tr.length(); i++) {
                JSONObject o = tr.optJSONObject(i);
                if (o.optString("nombre").equalsIgnoreCase(nombre)) {
                    if (puesto) continue;                          // duplicado: se descarta
                    o.put("nombre", nombre);
                    if (forzar || !correo.isEmpty()) o.put("correo", correo);
                    puesto = true;
                }
                l.add(o);
            }
            if (!puesto) {
                JSONObject o = new JSONObject();
                o.put("nombre", nombre);
                o.put("correo", correo);
                l.add(o);
            }
            Collections.sort(l, (a, b) -> a.optString("nombre").compareToIgnoreCase(b.optString("nombre")));
            for (JSONObject o : l) nueva.put(o);
            guardarLista("trabajadores", nueva);
        } catch (Exception ignorada) { }
    }

    private void borrarTrabajador(String nombre) {
        JSONArray tr = leerLista("trabajadores"), nueva = new JSONArray();
        for (int i = 0; i < tr.length(); i++) if (!tr.optJSONObject(i).optString("nombre").equals(nombre)) nueva.put(tr.optJSONObject(i));
        guardarLista("trabajadores", nueva);
    }

    private File carpetaEntregas() {
        File f = new File(getFilesDir(), "entregas");
        //noinspection ResultOfMethodCallIgnored
        f.mkdirs();
        return f;
    }

    private static byte[] leerArchivo(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        in.close();
        return b.toByteArray();
    }

    private static String hoy() {
        return new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
    }

    private static String sinAcentos(String s) {
        return Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }

    private static String unir(List<String> l, String sep) {
        StringBuilder b = new StringBuilder();
        for (String s : l) { if (b.length() > 0) b.append(sep); b.append(s); }
        return b.toString();
    }

    // ======================================================================
    // Recuadro de firma
    // ======================================================================
    static class Firma extends View {
        private final Path trazo = new Path();
        private final Paint tinta = new Paint(Paint.ANTI_ALIAS_FLAG), pista = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF limites = new RectF();
        private boolean vacia = true;
        private float ux, uy;

        Firma(Context c) {
            super(c);
            float d = c.getResources().getDisplayMetrics().density;
            tinta.setColor(TINTA);
            tinta.setStyle(Paint.Style.STROKE);
            tinta.setStrokeWidth(2.6f * d);
            tinta.setStrokeCap(Paint.Cap.ROUND);
            tinta.setStrokeJoin(Paint.Join.ROUND);
            pista.setColor(BORDE);
            pista.setTextSize(18 * d);
            pista.setTextAlign(Paint.Align.CENTER);
        }

        boolean vacia() { return vacia; }

        void borrar() {
            trazo.reset();
            vacia = true;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            float d = getResources().getDisplayMetrics().density;
            if (vacia) c.drawText("Firme aquí con el dedo", getWidth() / 2f, getHeight() / 2f, pista);
            c.drawLine(20 * d, getHeight() - 40 * d, getWidth() - 20 * d, getHeight() - 40 * d, pista);
            c.drawPath(trazo, tinta);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX(), y = e.getY();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);   // que no se mueva la pantalla al firmar
                    trazo.moveTo(x, y);
                    trazo.lineTo(x + 0.1f, y);
                    ux = x; uy = y;
                    vacia = false;
                    break;
                case MotionEvent.ACTION_MOVE:
                    for (int i = 0; i < e.getHistorySize(); i++) punto(e.getHistoricalX(i), e.getHistoricalY(i));
                    punto(x, y);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    getParent().requestDisallowInterceptTouchEvent(false);
                    break;
                default:
                    break;
            }
            invalidate();
            return true;
        }

        private void punto(float x, float y) {
            trazo.quadTo(ux, uy, (x + ux) / 2, (y + uy) / 2);
            ux = x; uy = y;
        }

        /** La firma recortada a su tamaño, con fondo transparente. */
        Bitmap recorte() {
            if (vacia) return null;
            trazo.computeBounds(limites, true);
            float m = tinta.getStrokeWidth() * 2;
            int l = (int) Math.max(0, limites.left - m), t = (int) Math.max(0, limites.top - m);
            int r = (int) Math.min(getWidth(), limites.right + m), b = (int) Math.min(getHeight(), limites.bottom + m);
            if (r - l < 2 || b - t < 2) { l = 0; t = 0; r = getWidth(); b = getHeight(); }
            Bitmap bmp = Bitmap.createBitmap(r - l, b - t, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            c.translate(-l, -t);
            c.drawPath(trazo, tinta);
            return bmp;
        }
    }
}
