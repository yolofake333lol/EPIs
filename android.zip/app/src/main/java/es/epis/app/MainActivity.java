package es.epis.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    // ---- Configuración ----
    private static final String CLAVE = "c666ad36462926e02c8c2ceb";   // la misma que en el script de Google
    private static final String VERSION = "EPIs v1.0";
    private static final String FIRMA_AUTOR = "BBF";
    private static final String OBRA_INICIAL = "MTO. Y CONSERVACIÓN VÍAS FÉRREAS ARCELOR MITTAL ASTURIAS";
    private static final String SEGURIDAD_INICIAL = "jfernandezg@azvi.es";
    private static final String NUMERO_OBRA = "2184";   // nº de obra: fijo, no se puede cambiar desde la app
    private static final String EPIS_INICIALES =
            "Casco de seguridad con barbuquejo\n"
            + "Traje de agua alta visibilidad\n"
            + "Botas de seguridad\n"
            + "Polar alta visibilidad\n"
            + "Camisa alta visibilidad\n"
            + "Guantes de cuero\n"
            + "Chaqueton de invierno\n"
            + "Pantalón alta visibilidad\n"
            + "\n"
            + "Gafas antiproyecciones\n"
            + "Candado personal de seguridad";
    private static final int MAX_FILAS = HojaEpi.FILAS * 2;
    private static final long PULSACION_URL_MS = 3000;

    // ---- Colores corporativos Azvi ----
    static final int AZUL = 0xFF1B4E91, AZUL_OSCURO = 0xFF123A6E, AZUL_CLARO = 0xFFEAF1FB, AZUL_SUAVE = 0xFFC9DAF2;
    static final int FONDO = 0xFFF2F5F9, TEXTO = 0xFF0F1B2D, GRIS = 0xFF5A6577, GRIS_CLARO = 0xFF6B7686;
    static final int BORDE = 0xFFD8E0EA, BORDE_FUERTE = 0xFFA9B6C6, CAMPO = 0xFFF7F9FC, BLANCO = 0xFFFFFFFF;
    static final int VERDE = 0xFF1E7B3A, VERDE_CLARO = 0xFFE6F4EA;
    static final int NARANJA = 0xFFB35400, NARANJA_CLARO = 0xFFFFF1E3, NARANJA_BORDE = 0xFFF3C99B;
    static final int ROJO = 0xFFB3261E, ROJO_CLARO = 0xFFFDECEA, TINTA = 0xFF0B1F5C;

    private static final int MP = ViewGroup.LayoutParams.MATCH_PARENT, WC = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int PRINCIPAL = 0, SECUNDARIO = 1, PELIGRO = 2, SUAVE = 3;

    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean enviando = false;
    private Typeface tTitulo, tTituloMedio, tTexto, tMedio, tFuerte;

    // ---- Pantallas ----
    private FrameLayout raiz;
    private final List<Pantalla> pila = new ArrayList<>();
    private Pantalla pEntrega, pFirma, pHistorial, pAjustes, pTrabajadores;
    private boolean animando = false;
    private FrameLayout capaHoja;
    private LinearLayout tarjetaHoja;
    private boolean hojaCancelable = true;

    // Entrega
    private TextView chipNumero, chipFecha, contadorEpis, avisoPendientes;
    private View marcaGuardado;
    private AutoCompleteTextView campoNombre;
    private EditText campoCorreo, campoOtros;
    private LinearLayout listaEpis;
    private final List<FilaEpi> filas = new ArrayList<>();

    // Firma
    private TextView firmaSobre, firmaIniciales, resumenNombre, resumenCorreo;
    private Fluir resumenEpis;
    private Firma firma;
    private Boton botonEnviar;

    // Historial
    private LinearLayout listaHistorial;
    private TextView statAnio, statEnviadas, statPendientes;
    private EditText campoBuscar;

    // Ajustes
    private EditText ajSeguridad, ajObra;
    private TextView ajEstado, ajCuentaEpis, ajUrlTexto, cuentaTrabajadores;
    private LinearLayout ajListaEpis;
    private final List<String> ajEpis = new ArrayList<>();
    private boolean ajCambios = false, ajCargando = false;
    private Runnable abrirEditorUrl;
    private float arrastreY0;

    // Trabajadores
    private LinearLayout listaTrabajadores;

    // ======================================================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("datos", MODE_PRIVATE);
        if (!prefs.contains("epis")) prefs.edit().putString("epis", EPIS_INICIALES).apply();
        if (!prefs.contains("obra")) prefs.edit().putString("obra", OBRA_INICIAL).apply();
        if (!prefs.contains("seguridad")) prefs.edit().putString("seguridad", SEGURIDAD_INICIAL).apply();

        tTitulo = fuente("Outfit-Bold.ttf");
        tTituloMedio = fuente("Outfit-SemiBold.ttf");
        tTexto = fuente("WorkSans-Regular.ttf");
        tMedio = fuente("WorkSans-Medium.ttf");
        tFuerte = fuente("WorkSans-SemiBold.ttf");

        Window w = getWindow();
        w.setStatusBarColor(BLANCO);
        int banderas = 0;
        if (Build.VERSION.SDK_INT >= 23) banderas |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 27) {
            w.setNavigationBarColor(BLANCO);
            banderas |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        w.getDecorView().setSystemUiVisibility(banderas);

        raiz = new FrameLayout(this);
        raiz.setBackgroundColor(FONDO);
        setContentView(raiz);

        crearEntrega();
        crearFirma();
        crearHistorial();
        crearAjustes();
        crearTrabajadores();

        pila.add(pEntrega);
        pEntrega.raiz.setVisibility(View.VISIBLE);
        alMostrar(pEntrega);
    }

    private Typeface fuente(String archivo) {
        try { return Typeface.createFromAsset(getAssets(), "fuentes/" + archivo); }
        catch (Exception ex) { return Typeface.DEFAULT; }
    }

    @Override
    protected void onResume() {
        super.onResume();
        pintarAvisoPendientes();
        reintentarPendientes(false);
    }

    @Override
    public void onBackPressed() {
        if (capaHoja != null) { if (hojaCancelable) cerrarHoja(null); return; }
        if (animando || enviando) return;
        if (pila.size() > 1) {
            Pantalla actual = pila.get(pila.size() - 1);
            if (actual == pAjustes && ajCambios) { preguntarGuardarAjustes(); return; }
            volver();
            return;
        }
        super.onBackPressed();
    }

    // ======================================================================
    // Navegación con animación de deslizamiento
    // ======================================================================
    private static class Pantalla {
        FrameLayout raiz;
        LinearLayout contenido, banda, barra;
        ScrollView scroll;
    }

    private void ir(Pantalla nueva) {
        if (animando) return;
        ocultarTeclado();
        final Pantalla actual = pila.get(pila.size() - 1);
        pila.add(nueva);
        alMostrar(nueva);
        nueva.scroll.scrollTo(0, 0);
        float ancho = raiz.getWidth();
        animando = true;
        nueva.raiz.setVisibility(View.VISIBLE);
        nueva.raiz.bringToFront();
        nueva.raiz.setTranslationX(ancho);
        nueva.raiz.animate().translationX(0).setDuration(300).setInterpolator(new DecelerateInterpolator(2.2f)).start();
        actual.raiz.animate().translationX(-ancho * 0.25f).setDuration(300).setInterpolator(new DecelerateInterpolator(2.2f))
                .withEndAction(() -> {
                    actual.raiz.setVisibility(View.GONE);
                    actual.raiz.setTranslationX(0);
                    animando = false;
                }).start();
    }

    private void volver() {
        volverHasta(pila.size() - 2);
    }

    private void volverHasta(int indice) {
        if (animando || pila.size() <= 1 || indice < 0) return;
        ocultarTeclado();
        final Pantalla actual = pila.get(pila.size() - 1);
        while (pila.size() - 1 > indice) {
            Pantalla p = pila.remove(pila.size() - 1);
            if (p != actual) p.raiz.setVisibility(View.GONE);
        }
        Pantalla anterior = pila.get(pila.size() - 1);
        alMostrar(anterior);
        float ancho = raiz.getWidth();
        animando = true;
        anterior.raiz.setVisibility(View.VISIBLE);
        anterior.raiz.setTranslationX(-ancho * 0.25f);
        anterior.raiz.animate().translationX(0).setDuration(260).setInterpolator(new DecelerateInterpolator(2f)).start();
        actual.raiz.bringToFront();
        actual.raiz.animate().translationX(ancho).setDuration(260).setInterpolator(new AccelerateInterpolator(1.4f))
                .withEndAction(() -> {
                    actual.raiz.setVisibility(View.GONE);
                    actual.raiz.setTranslationX(0);
                    animando = false;
                }).start();
    }

    private void alMostrar(Pantalla p) {
        if (p == pEntrega) { pintarCabeceraEntrega(); pintarEpis(); pintarAvisoPendientes(); }
        else if (p == pFirma) pintarResumen();
        else if (p == pHistorial) { campoBuscar.setText(""); pintarHistorial(); }
        else if (p == pAjustes) { if (!ajCambios) cargarAjustes(); else actualizarCuentaTrabajadores(); }
        else if (p == pTrabajadores) pintarTrabajadores();
    }

    private void ocultarTeclado() {
        View v = getCurrentFocus();
        if (v != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
            v.clearFocus();
        }
    }

    // ======================================================================
    // Piezas de diseño
    // ======================================================================
    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private GradientDrawable forma(int color, int borde, float bordeDp, float radio) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radio));
        if (borde != 0) g.setStroke(dp(bordeDp), borde);
        return g;
    }

    private Drawable conOnda(Drawable fondo, int colorOnda) {
        return new RippleDrawable(ColorStateList.valueOf(colorOnda), fondo, null);
    }

    private TextView texto(String s, float sp, int color, Typeface tf) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(tf);
        return t;
    }

    private ImageView icono(int res, int color, int tam) {
        ImageView i = new ImageView(this);
        i.setImageResource(res);
        i.setImageTintList(ColorStateList.valueOf(color));
        i.setLayoutParams(new LinearLayout.LayoutParams(dp(tam), dp(tam)));
        return i;
    }

    private LinearLayout.LayoutParams lp(int ancho, int alto) {
        return new LinearLayout.LayoutParams(ancho, alto);
    }

    private LinearLayout.LayoutParams lpArriba(int ancho, int alto, int margenDp) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(ancho, alto);
        l.topMargin = dp(margenDp);
        return l;
    }

    private LinearLayout fila() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout columna() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    /** Botón cuadrado con icono para la barra superior. */
    private View botonBarra(int icono, String descripcion, View.OnClickListener accion) {
        FrameLayout b = new FrameLayout(this);
        b.setBackground(conOnda(forma(FONDO, 0, 0, 14), 0x221B4E91));
        b.setContentDescription(descripcion);
        b.setClickable(true);
        b.setOnClickListener(accion);
        b.addView(icono(icono, AZUL, 22), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        return b;
    }

    private Pantalla crearPantalla(String sobre, String titulo, View izquierda, View derecha, boolean conBarra) {
        Pantalla p = new Pantalla();
        p.raiz = new FrameLayout(this);
        p.raiz.setBackgroundColor(FONDO);
        p.raiz.setVisibility(View.GONE);
        p.raiz.setClickable(true);

        LinearLayout col = columna();
        p.raiz.addView(col, new FrameLayout.LayoutParams(MP, MP));

        // Barra superior: botón · logo centrado · botón
        FrameLayout barra = new FrameLayout(this);
        barra.setBackgroundColor(BLANCO);
        barra.setPadding(dp(12), dp(10), dp(12), dp(10));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_asturias);
        logo.setAdjustViewBounds(true);
        logo.setContentDescription("Azvi Asturias");
        barra.addView(logo, new FrameLayout.LayoutParams(WC, dp(54), Gravity.CENTER));
        if (izquierda != null) barra.addView(izquierda, new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START | Gravity.CENTER_VERTICAL));
        if (derecha != null) barra.addView(derecha, new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END | Gravity.CENTER_VERTICAL));
        col.addView(barra, lp(MP, WC));

        p.scroll = new ScrollView(this);
        p.scroll.setFillViewport(true);
        p.scroll.setVerticalScrollBarEnabled(false);
        p.scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout dentro = columna();
        p.scroll.addView(dentro, new FrameLayout.LayoutParams(MP, WC));
        col.addView(p.scroll, new LinearLayout.LayoutParams(MP, 0, 1));

        // Franja azul con el título
        p.banda = columna();
        GradientDrawable fb = new GradientDrawable();
        fb.setColor(AZUL);
        float r = dp(28);
        fb.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        p.banda.setBackground(fb);
        p.banda.setPadding(dp(20), dp(18), dp(20), dp(22));
        TextView s = texto(sobre, 12, AZUL_SUAVE, tFuerte);
        s.setLetterSpacing(0.12f);
        p.banda.addView(s);
        TextView t = texto(titulo, 30, BLANCO, tTitulo);
        t.setPadding(0, dp(2), 0, 0);
        p.banda.addView(t);
        dentro.addView(p.banda, lp(MP, WC));

        p.contenido = columna();
        p.contenido.setPadding(dp(16), dp(4), dp(16), dp(conBarra ? 130 : 32));
        dentro.addView(p.contenido, lp(MP, WC));

        if (conBarra) {
            p.barra = columna();
            p.barra.setBackgroundColor(BLANCO);
            p.barra.setElevation(dp(16));
            p.barra.setPadding(dp(16), dp(12), dp(16), dp(18));
            p.raiz.addView(p.barra, new FrameLayout.LayoutParams(MP, WC, Gravity.BOTTOM));
        }
        raiz.addView(p.raiz, new FrameLayout.LayoutParams(MP, MP));
        return p;
    }

    private LinearLayout tarjeta(LinearLayout padre) {
        LinearLayout t = columna();
        t.setPadding(dp(18), dp(16), dp(18), dp(18));
        t.setBackground(forma(BLANCO, 0, 0, 20));
        t.setElevation(dp(2));
        LinearLayout.LayoutParams l = lpArriba(MP, WC, 14);
        l.leftMargin = dp(1);
        l.rightMargin = dp(1);
        padre.addView(t, l);
        return t;
    }

    private View cuadroIcono(int icono) {
        FrameLayout cuadro = new FrameLayout(this);
        cuadro.setBackground(forma(AZUL_CLARO, 0, 0, 10));
        cuadro.addView(icono(icono, AZUL, 18), new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER));
        cuadro.setLayoutParams(lp(dp(34), dp(34)));
        return cuadro;
    }

    private void encabezado(LinearLayout tarjeta, int icono, String titulo, View derecha) {
        LinearLayout f = fila();
        f.addView(cuadroIcono(icono));
        TextView t = texto(titulo, 18, TEXTO, tTituloMedio);
        t.setPadding(dp(10), 0, 0, 0);
        f.addView(t, new LinearLayout.LayoutParams(0, WC, 1));
        if (derecha != null) f.addView(derecha);
        tarjeta.addView(f, lp(MP, WC));
    }

    private TextView etiqueta(LinearLayout padre, String s) {
        TextView t = texto(s, 13, GRIS, tFuerte);
        t.setPadding(0, dp(12), 0, dp(6));
        padre.addView(t);
        return t;
    }

    private Drawable fondoCampo() {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, forma(BLANCO, AZUL, 2, 14));
        s.addState(new int[]{}, forma(CAMPO, BORDE, 1, 14));
        return s;
    }

    private void prepararCampo(EditText e, String pista, int tipo) {
        e.setHint(pista);
        e.setInputType(tipo);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        e.setTypeface(tTexto);
        e.setTextColor(TEXTO);
        e.setHintTextColor(0xFF8A95A5);
        e.setMinHeight(dp(52));
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setBackground(fondoCampo());
    }

    private EditText campo(LinearLayout padre, String pista, int tipo) {
        EditText e = new EditText(this);
        prepararCampo(e, pista, tipo);
        padre.addView(e, lp(MP, WC));
        return e;
    }

    /** Botón con icono, texto y rueda de carga. */
    private static class Boton {
        LinearLayout vista;
        TextView texto;
        ImageView icono;
        ProgressBar carga;
        String textoNormal;

        void cargando(boolean si, String mientras) {
            vista.setEnabled(!si);
            carga.setVisibility(si ? View.VISIBLE : View.GONE);
            if (icono != null) icono.setVisibility(si ? View.GONE : View.VISIBLE);
            texto.setText(si ? mientras : textoNormal);
        }
    }

    private Boton boton(String s, int icono, boolean iconoDetras, int tipo) {
        Boton b = new Boton();
        b.textoNormal = s;
        b.vista = fila();
        b.vista.setGravity(Gravity.CENTER);
        b.vista.setClickable(true);
        b.vista.setPadding(dp(18), 0, dp(18), 0);
        int color;
        if (tipo == PRINCIPAL) { b.vista.setBackground(conOnda(forma(AZUL, 0, 0, 16), 0x40FFFFFF)); color = BLANCO; }
        else if (tipo == PELIGRO) { b.vista.setBackground(conOnda(forma(ROJO_CLARO, 0, 0, 16), 0x22B3261E)); color = ROJO; }
        else if (tipo == SUAVE) { b.vista.setBackground(conOnda(forma(BLANCO, BORDE, 1, 12), 0x221B4E91)); color = GRIS; }
        else { b.vista.setBackground(conOnda(forma(BLANCO, AZUL, 2, 14), 0x221B4E91)); color = AZUL; }
        b.carga = new ProgressBar(this);
        b.carga.setIndeterminateTintList(ColorStateList.valueOf(color));
        b.carga.setVisibility(View.GONE);
        LinearLayout.LayoutParams lc = lp(dp(22), dp(22));
        lc.rightMargin = dp(10);
        b.vista.addView(b.carga, lc);
        if (icono != 0 && !iconoDetras) {
            b.icono = icono(icono, color, 20);
            LinearLayout.LayoutParams li = lp(dp(20), dp(20));
            li.rightMargin = dp(10);
            b.vista.addView(b.icono, li);
        }
        b.texto = texto(s, tipo == PRINCIPAL ? 19 : 16, color, tipo == PRINCIPAL ? tTituloMedio : tFuerte);
        b.vista.addView(b.texto);
        if (icono != 0 && iconoDetras) {
            b.icono = icono(icono, color, 20);
            LinearLayout.LayoutParams li = lp(dp(20), dp(20));
            li.leftMargin = dp(10);
            b.vista.addView(b.icono, li);
        }
        return b;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static String iniciales(String nombre) {
        StringBuilder b = new StringBuilder();
        for (String p : nombre.trim().split("\\s+")) {
            if (!p.isEmpty() && b.length() < 2) b.append(Character.toUpperCase(p.charAt(0)));
        }
        return b.length() == 0 ? "?" : b.toString();
    }

    private TextView avatar(String nombre, int color, int fondo) {
        TextView av = texto(iniciales(nombre), 15, color, tTitulo);
        av.setGravity(Gravity.CENTER);
        av.setBackground(forma(fondo, 0, 0, 999));
        av.setLayoutParams(lp(dp(42), dp(42)));
        return av;
    }

    // ======================================================================
    // Hojas que suben desde abajo (avisos, preguntas, formularios)
    // ======================================================================
    private LinearLayout nuevaHoja(String titulo, String mensaje) {
        LinearLayout h = columna();
        GradientDrawable fh = new GradientDrawable();
        fh.setColor(BLANCO);
        float r = dp(28);
        fh.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        h.setBackground(fh);
        h.setPadding(dp(22), dp(10), dp(22), dp(24));
        h.setClickable(true);
        View asa = new View(this);
        asa.setBackground(forma(BORDE, 0, 0, 3));
        LinearLayout.LayoutParams la = lp(dp(40), dp(5));
        la.gravity = Gravity.CENTER_HORIZONTAL;
        la.bottomMargin = dp(16);
        h.addView(asa, la);
        if (titulo != null) h.addView(texto(titulo, 22, TEXTO, tTitulo));
        if (mensaje != null) {
            TextView m = texto(mensaje, 16, GRIS, tTexto);
            m.setLineSpacing(0, 1.25f);
            m.setPadding(0, dp(8), 0, dp(4));
            h.addView(m);
        }
        return h;
    }

    private void botonHoja(LinearLayout hoja, String s, int tipo, Runnable accion) {
        Boton b = boton(s, 0, false, tipo);
        b.vista.setOnClickListener(v -> cerrarHoja(accion));
        hoja.addView(b.vista, lpArriba(MP, dp(tipo == PRINCIPAL ? 56 : 52), 10));
    }

    private void mostrarHoja(final LinearLayout hoja, boolean cancelable) {
        if (capaHoja != null) { raiz.removeView(capaHoja); capaHoja = null; }
        ocultarTeclado();
        hojaCancelable = cancelable;
        FrameLayout capa = new FrameLayout(this);
        View velo = new View(this);
        velo.setBackgroundColor(0x990F1B2D);
        velo.setAlpha(0f);
        velo.setOnClickListener(v -> { if (hojaCancelable) cerrarHoja(null); });
        capa.addView(velo, new FrameLayout.LayoutParams(MP, MP));
        capa.addView(hoja, new FrameLayout.LayoutParams(MP, WC, Gravity.BOTTOM));
        raiz.addView(capa, new FrameLayout.LayoutParams(MP, MP));
        capaHoja = capa;
        tarjetaHoja = hoja;
        velo.animate().alpha(1f).setDuration(220).start();
        hoja.setTranslationY(dp(900));
        hoja.post(() -> {
            hoja.setTranslationY(hoja.getHeight());
            hoja.animate().translationY(0).setDuration(320).setInterpolator(new DecelerateInterpolator(2.4f)).start();
        });
    }

    private void cerrarHoja(final Runnable despues) {
        final FrameLayout capa = capaHoja;
        if (capa == null) { if (despues != null) despues.run(); return; }
        capaHoja = null;
        ocultarTeclado();
        capa.getChildAt(0).animate().alpha(0f).setDuration(200).start();
        tarjetaHoja.animate().translationY(tarjetaHoja.getHeight()).setDuration(200).setInterpolator(new AccelerateInterpolator(1.5f))
                .withEndAction(() -> raiz.removeView(capa)).start();
        if (despues != null) handler.postDelayed(despues, 150);
    }

    private void aviso(String titulo, String mensaje) {
        LinearLayout h = nuevaHoja(titulo, mensaje);
        botonHoja(h, "Entendido", PRINCIPAL, null);
        mostrarHoja(h, true);
    }

    private interface AlEscribir { void con(String valor); }

    /** Hoja con un campo de texto. */
    private void pedirTexto(String titulo, String mensaje, String valor, int tipo, String textoBoton, final AlEscribir accion) {
        LinearLayout h = nuevaHoja(titulo, mensaje);
        final EditText e = new EditText(this);
        prepararCampo(e, "", tipo);
        e.setText(valor);
        e.setSelection(e.getText().length());
        h.addView(e, lpArriba(MP, WC, 12));
        botonHoja(h, textoBoton, PRINCIPAL, () -> accion.con(e.getText().toString().trim()));
        botonHoja(h, "Cancelar", SUAVE, null);
        mostrarHoja(h, true);
        mostrarTeclado(e);
    }

    private void mostrarTeclado(final EditText e) {
        handler.postDelayed(() -> {
            e.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(e, InputMethodManager.SHOW_IMPLICIT);
        }, 380);
    }

    // ======================================================================
    // Pantalla 1: nueva entrega (trabajador y EPIs)
    // ======================================================================
    private void crearEntrega() {
        View hist = botonBarra(R.drawable.ic_historial, "Historial", v -> ir(pHistorial));
        View ajus = botonBarra(R.drawable.ic_ajustes, "Ajustes", v -> ir(pAjustes));
        pEntrega = crearPantalla("MOD. 335 · RECIBÍ DE EPIs", "Nueva entrega", hist, ajus, true);

        // Número, fecha y pasos dentro de la franja azul
        LinearLayout chips = fila();
        chipNumero = chipBanda(chips, R.drawable.ic_numero);
        chipFecha = chipBanda(chips, R.drawable.ic_calendario);
        pEntrega.banda.addView(chips, lpArriba(MP, WC, 14));
        pEntrega.banda.addView(pasos(2), lpArriba(MP, WC, 16));

        LinearLayout c = pEntrega.contenido;

        avisoPendientes = texto("", 15, BLANCO, tFuerte);
        avisoPendientes.setBackground(conOnda(forma(NARANJA, 0, 0, 16), 0x33FFFFFF));
        avisoPendientes.setPadding(dp(16), dp(14), dp(16), dp(14));
        avisoPendientes.setOnClickListener(v -> reintentarPendientes(true));
        c.addView(avisoPendientes, lpArriba(MP, WC, 14));

        // --- Trabajador ---
        LinearLayout t = tarjeta(c);
        encabezado(t, R.drawable.ic_usuario, "Trabajador", null);
        etiqueta(t, "Nombre y apellidos");
        campoNombre = new AutoCompleteTextView(this);
        prepararCampo(campoNombre, "Escribe el nombre", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        campoNombre.setThreshold(1);
        campoNombre.setDropDownBackgroundDrawable(forma(BLANCO, BORDE, 1, 14));
        t.addView(campoNombre, lp(MP, WC));
        campoNombre.setOnItemClickListener((parent, view, pos, id) -> {
            String correo = correoDe(campoNombre.getText().toString());
            if (correo != null) campoCorreo.setText(correo);
            ocultarTeclado();
        });
        campoNombre.addTextChangedListener(new Vigia() {
            @Override public void afterTextChanged(Editable s) {
                String correo = correoDe(s.toString());
                marcaGuardado.setVisibility(correo != null ? View.VISIBLE : View.GONE);
                if (correo != null && campoCorreo.getText().length() == 0) campoCorreo.setText(correo);
            }
        });

        LinearLayout filaCorreo = fila();
        filaCorreo.addView(texto("Correo", 13, GRIS, tFuerte), new LinearLayout.LayoutParams(0, WC, 1));
        LinearLayout guardado = fila();
        guardado.addView(icono(R.drawable.ic_check, VERDE, 14));
        TextView tg = texto("Trabajador guardado", 12, VERDE, tFuerte);
        tg.setPadding(dp(4), 0, 0, 0);
        guardado.addView(tg);
        guardado.setVisibility(View.GONE);
        marcaGuardado = guardado;
        filaCorreo.addView(guardado);
        filaCorreo.setPadding(0, dp(12), 0, dp(6));
        t.addView(filaCorreo, lp(MP, WC));
        campoCorreo = campo(t, "nombre@correo.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);

        // --- EPIs ---
        LinearLayout e = tarjeta(c);
        contadorEpis = texto("0", 13, BLANCO, tFuerte);
        contadorEpis.setBackground(forma(AZUL, 0, 0, 999));
        contadorEpis.setPadding(dp(10), dp(3), dp(10), dp(3));
        encabezado(e, R.drawable.ic_casco, "EPIs que se entregan", contadorEpis);
        listaEpis = columna();
        listaEpis.setPadding(0, dp(6), 0, 0);
        e.addView(listaEpis, lp(MP, WC));
        etiqueta(e, "Otros (separados por comas)");
        campoOtros = campo(e, "Ej.: Tapones auditivos", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        campoOtros.addTextChangedListener(new Vigia() {
            @Override public void afterTextChanged(Editable s) { pintarContador(); }
        });

        Boton seguir = boton("Continuar a la firma", R.drawable.ic_flecha, true, PRINCIPAL);
        seguir.vista.setOnClickListener(v -> continuarAFirma());
        pEntrega.barra.addView(seguir.vista, lp(MP, dp(58)));
    }

    private TextView chipBanda(LinearLayout padre, int icono) {
        LinearLayout ch = fila();
        ch.setBackground(forma(0x24FFFFFF, 0, 0, 999));
        ch.setPadding(dp(12), dp(7), dp(14), dp(7));
        ch.addView(icono(icono, BLANCO, 16));
        TextView t = texto("", 14, BLANCO, tFuerte);
        t.setPadding(dp(6), 0, 0, 0);
        ch.addView(t);
        LinearLayout.LayoutParams l = lp(WC, WC);
        l.rightMargin = dp(8);
        padre.addView(ch, l);
        return t;
    }

    /** Las tres rayitas de progreso: Trabajador · EPIs · Firma. */
    private LinearLayout pasos(int hechos) {
        LinearLayout f = fila();
        f.setGravity(Gravity.TOP);
        String[] nombres = {"1 · Trabajador", "2 · EPIs", "3 · Firma"};
        for (int i = 0; i < 3; i++) {
            LinearLayout col = columna();
            View raya = new View(this);
            raya.setBackground(forma(i < hechos ? BLANCO : 0x4DFFFFFF, 0, 0, 4));
            col.addView(raya, lp(MP, dp(4)));
            TextView t = texto(nombres[i], 12, i < hechos ? BLANCO : AZUL_SUAVE, i < hechos ? tFuerte : tMedio);
            t.setPadding(0, dp(6), 0, 0);
            col.addView(t);
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, WC, 1);
            if (i < 2) l.rightMargin = dp(6);
            f.addView(col, l);
        }
        return f;
    }

    private void pintarCabeceraEntrega() {
        chipNumero.setText("Obra " + NUMERO_OBRA);
        chipFecha.setText(hoy());
        List<String> nombres = new ArrayList<>();
        JSONArray tr = leerLista("trabajadores");
        for (int i = 0; i < tr.length(); i++) nombres.add(tr.optJSONObject(i).optString("nombre"));
        campoNombre.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, nombres) {
            @Override public View getView(int pos, View convertView, ViewGroup parent) {
                TextView v = (TextView) super.getView(pos, convertView, parent);
                v.setTypeface(tMedio);
                v.setTextColor(TEXTO);
                v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
                v.setPadding(dp(16), dp(14), dp(16), dp(14));
                return v;
            }
        });
    }

    /** Fila de EPI que se marca tocándola. */
    private static class FilaEpi {
        String nombre;
        boolean marcada;
        LinearLayout vista;
        FrameLayout caja;
        ImageView tic;
        TextView texto;
    }

    private void pintarEpis() {
        List<String> marcadas = new ArrayList<>();
        for (FilaEpi f : filas) if (f.marcada) marcadas.add(f.nombre);
        listaEpis.removeAllViews();
        filas.clear();
        for (String epi : episConfigurados()) {
            if (epi.trim().isEmpty()) continue;
            final FilaEpi f = new FilaEpi();
            f.nombre = epi.trim();
            f.marcada = marcadas.contains(f.nombre);
            f.vista = fila();
            f.vista.setMinimumHeight(dp(54));
            f.vista.setPadding(dp(12), dp(8), dp(12), dp(8));
            f.vista.setClickable(true);
            f.caja = new FrameLayout(this);
            f.tic = icono(R.drawable.ic_check, BLANCO, 16);
            f.caja.addView(f.tic, new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER));
            f.vista.addView(f.caja, lp(dp(26), dp(26)));
            f.texto = texto(f.nombre, 16, TEXTO, tMedio);
            f.texto.setPadding(dp(12), 0, 0, 0);
            f.vista.addView(f.texto, new LinearLayout.LayoutParams(0, WC, 1));
            f.vista.setOnClickListener(v -> {
                f.marcada = !f.marcada;
                pintarFila(f, true);
                pintarContador();
            });
            pintarFila(f, false);
            listaEpis.addView(f.vista, lpArriba(MP, WC, 8));
            filas.add(f);
        }
        pintarContador();
    }

    private void pintarFila(FilaEpi f, boolean animar) {
        if (f.marcada) {
            f.vista.setBackground(conOnda(forma(AZUL_CLARO, AZUL, 2, 14), 0x221B4E91));
            f.caja.setBackground(forma(AZUL, 0, 0, 8));
            f.tic.setVisibility(View.VISIBLE);
            f.texto.setTypeface(tFuerte);
        } else {
            f.vista.setBackground(conOnda(forma(BLANCO, BORDE, 1, 14), 0x221B4E91));
            f.caja.setBackground(forma(BLANCO, BORDE_FUERTE, 2, 8));
            f.tic.setVisibility(View.INVISIBLE);
            f.texto.setTypeface(tMedio);
        }
        if (animar) {
            f.caja.setScaleX(0.6f);
            f.caja.setScaleY(0.6f);
            f.caja.animate().scaleX(1f).scaleY(1f).setDuration(280).setInterpolator(new OvershootInterpolator(3.5f)).start();
        }
    }

    private void pintarContador() {
        int n = otros().size();
        for (FilaEpi f : filas) if (f.marcada) n++;
        contadorEpis.setText(String.valueOf(n));
        contadorEpis.setVisibility(n > 0 ? View.VISIBLE : View.INVISIBLE);
    }

    private List<String> entregados() {
        List<String> l = new ArrayList<>();
        for (FilaEpi f : filas) if (f.marcada) l.add(f.nombre);
        return l;
    }

    private List<String> otros() {
        List<String> l = new ArrayList<>();
        if (campoOtros == null) return l;
        for (String o : campoOtros.getText().toString().split(",")) if (!o.trim().isEmpty()) l.add(o.trim());
        return l;
    }

    private String nombreLimpio() {
        return campoNombre.getText().toString().trim().replaceAll("\\s+", " ");
    }

    private void pintarAvisoPendientes() {
        if (avisoPendientes == null) return;
        int n = 0;
        JSONArray en = leerLista("entregas");
        for (int i = 0; i < en.length(); i++) if (!en.optJSONObject(i).optBoolean("enviado")) n++;
        avisoPendientes.setVisibility(n == 0 ? View.GONE : View.VISIBLE);
        avisoPendientes.setText(n == 1
                ? "1 entrega sin enviar. Toca para reintentar."
                : n + " entregas sin enviar. Toca para reintentar.");
    }

    private void continuarAFirma() {
        ocultarTeclado();
        String nombre = nombreLimpio();
        String correo = campoCorreo.getText().toString().trim();
        if (nombre.isEmpty()) { aviso("Falta el nombre", "Escribe el nombre y apellidos del trabajador."); return; }
        if (!correo.isEmpty() && !Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
            aviso("Correo no válido", "Revisa el correo del trabajador. Si no tiene, déjalo en blanco y solo se enviará al técnico de seguridad.");
            return;
        }
        if (entregados().isEmpty() && otros().isEmpty()) { aviso("Faltan los EPIs", "Marca al menos un EPI de la lista."); return; }
        ir(pFirma);
    }

    // ======================================================================
    // Pantalla 2: firma y envío
    // ======================================================================
    private void crearFirma() {
        View atras = botonBarra(R.drawable.ic_volver, "Volver", v -> volver());
        pFirma = crearPantalla("", "Firma del trabajador", atras, null, true);
        firmaSobre = (TextView) pFirma.banda.getChildAt(0);

        // Iniciales del trabajador a la derecha del título
        TextView titulo = (TextView) pFirma.banda.getChildAt(1);
        pFirma.banda.removeView(titulo);
        titulo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        LinearLayout ft = fila();
        ft.addView(titulo, new LinearLayout.LayoutParams(0, WC, 1));
        firmaIniciales = texto("", 16, AZUL, tTitulo);
        firmaIniciales.setGravity(Gravity.CENTER);
        firmaIniciales.setBackground(forma(BLANCO, 0, 0, 999));
        ft.addView(firmaIniciales, lp(dp(44), dp(44)));
        pFirma.banda.addView(ft, lp(MP, WC));
        pFirma.banda.addView(pasos(3), lpArriba(MP, WC, 16));

        LinearLayout c = pFirma.contenido;

        // --- Resumen ---
        LinearLayout r = tarjeta(c);
        LinearLayout fr = fila();
        fr.addView(texto("Resumen", 17, TEXTO, tTituloMedio), new LinearLayout.LayoutParams(0, WC, 1));
        TextView editar = texto("Editar", 15, AZUL, tFuerte);
        editar.setGravity(Gravity.CENTER);
        editar.setPadding(dp(12), 0, dp(12), 0);
        editar.setBackground(conOnda(forma(BLANCO, 0, 0, 10), 0x221B4E91));
        editar.setOnClickListener(v -> volver());
        fr.addView(editar, lp(WC, dp(44)));
        r.addView(fr, lp(MP, WC));
        resumenNombre = texto("", 17, TEXTO, tFuerte);
        r.addView(resumenNombre);
        resumenCorreo = texto("", 14, GRIS, tTexto);
        r.addView(resumenCorreo);
        resumenEpis = new Fluir(this, dp(6));
        r.addView(resumenEpis, lpArriba(MP, WC, 12));

        // --- Firma ---
        LinearLayout f = tarjeta(c);
        encabezado(f, R.drawable.ic_firma, "Recibí conforme", null);
        TextView decl = texto("Declaro haber recibido los EPIs indicados y la información sobre su uso y mantenimiento.", 14, GRIS, tTexto);
        decl.setLineSpacing(0, 1.25f);
        decl.setPadding(0, dp(10), 0, dp(12));
        f.addView(decl);
        firma = new Firma(this, tTexto);
        GradientDrawable ff = forma(0xFFFBFCFE, 0, 0, 16);
        ff.setStroke(dp(2), BORDE_FUERTE, dp(8), dp(6));
        firma.setBackground(ff);
        f.addView(firma, lp(MP, dp(220)));
        Boton borrar = boton("Borrar firma", R.drawable.ic_deshacer, false, SUAVE);
        borrar.vista.setOnClickListener(v -> firma.borrar());
        LinearLayout.LayoutParams lb = lpArriba(WC, dp(46), 12);
        lb.gravity = Gravity.END;
        f.addView(borrar.vista, lb);

        // --- Abajo: nota y botón de enviar ---
        LinearLayout nota = fila();
        nota.setGravity(Gravity.CENTER);
        nota.addView(icono(R.drawable.ic_correo, GRIS, 15));
        TextView tn = texto("Se enviará al trabajador y al técnico de seguridad", 13, GRIS, tTexto);
        tn.setPadding(dp(6), 0, 0, 0);
        nota.addView(tn);
        pFirma.barra.addView(nota, lp(MP, WC));
        botonEnviar = boton("Generar y enviar", R.drawable.ic_enviar, false, PRINCIPAL);
        botonEnviar.vista.setOnClickListener(v -> generarYEnviar());
        pFirma.barra.addView(botonEnviar.vista, lpArriba(MP, dp(58), 10));
    }

    private void pintarResumen() {
        String nombre = nombreLimpio();
        String correo = campoCorreo.getText().toString().trim();
        firmaSobre.setText("OBRA " + NUMERO_OBRA + " · " + hoy());
        firmaIniciales.setText(iniciales(nombre));
        resumenNombre.setText(nombre);
        resumenCorreo.setText(correo.isEmpty() ? "Sin correo: solo se enviará al técnico de seguridad" : correo);
        resumenEpis.removeAllViews();
        List<String> todos = new ArrayList<>(entregados());
        todos.addAll(otros());
        for (String s : todos) {
            TextView ch = texto(s, 13, AZUL_OSCURO, tFuerte);
            ch.setBackground(forma(AZUL_CLARO, 0, 0, 999));
            ch.setPadding(dp(11), dp(6), dp(11), dp(6));
            resumenEpis.addView(ch);
        }
    }

    private void generarYEnviar() {
        if (enviando) return;
        if (firma.vacia()) { aviso("Falta la firma", "El trabajador tiene que firmar con el dedo en el recuadro."); return; }
        final String nombre = nombreLimpio();
        final String correo = campoCorreo.getText().toString().trim();
        final List<String> ent = entregados();
        final List<String> otr = otros();
        final int numero = prefs.getInt("siguiente", 1);
        final String fecha = hoy();

        botonEnviar.cargando(true, "Generando…");
        HojaEpi.Datos d = new HojaEpi.Datos();
        d.obra = prefs.getString("obra", OBRA_INICIAL);
        d.numero = NUMERO_OBRA;
        d.nombre = nombre;
        d.fecha = fecha;
        d.firma = firma.recorte();
        colocarEpis(d, ent, otr);

        String archivo = "Recibi_EPIs_" + sinAcentos(nombre).replaceAll("[^A-Za-z0-9]+", "_") + "_"
                + new SimpleDateFormat("dd-MM-yyyy_HHmm", Locale.getDefault()).format(new Date()) + ".pdf";
        try {
            escribirPdf(d, new File(carpetaEntregas(), archivo));
        } catch (Exception ex) {
            botonEnviar.cargando(false, null);
            aviso("No se ha podido crear el PDF", String.valueOf(ex.getMessage()));
            return;
        }

        List<String> todos = new ArrayList<>(ent);
        todos.addAll(otr);
        try {
            JSONObject en = new JSONObject();
            en.put("n", numero);
            en.put("fecha", fecha);
            en.put("nombre", nombre);
            en.put("correo", correo);
            en.put("epis", unir(todos, ", "));
            en.put("archivo", archivo);
            en.put("enviado", false);
            JSONArray lista = leerLista("entregas");
            lista.put(en);
            guardarLista("entregas", lista);
        } catch (Exception ignorada) { }
        prefs.edit().putInt("siguiente", numero + 1).apply();
        recordarTrabajador(nombre, correo);

        if (urlScript().isEmpty()) {
            botonEnviar.cargando(false, null);
            resultado(false, numero, correo, "Todavía no está configurado el envío de correos.");
            return;
        }
        botonEnviar.cargando(true, "Enviando…");
        enviar(numero, error -> {
            botonEnviar.cargando(false, null);
            pintarAvisoPendientes();
            resultado(error == null, numero, correo, error);
        });
    }

    /** Hoja final con el tic verde animado (o el reloj naranja si no se pudo enviar). */
    private void resultado(boolean ok, int numero, String correo, String error) {
        LinearLayout h = nuevaHoja(null, null);
        FrameLayout circulo = new FrameLayout(this);
        circulo.setBackground(forma(ok ? VERDE : NARANJA, 0, 0, 999));
        circulo.addView(icono(ok ? R.drawable.ic_check : R.drawable.ic_reloj, BLANCO, 40),
                new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER));
        LinearLayout.LayoutParams lc = lpArriba(dp(84), dp(84), 6);
        lc.gravity = Gravity.CENTER_HORIZONTAL;
        h.addView(circulo, lc);
        TextView t = texto(ok ? "Enviado" : "Guardada, sin enviar", 24, TEXTO, tTitulo);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(16), 0, 0);
        h.addView(t, lp(MP, WC));
        String msg = ok
                ? "El recibí se ha enviado " + (correo.isEmpty() ? "" : "a " + correo + " y ") + "al técnico de seguridad."
                : "El recibí queda guardado en el móvil y se enviará solo al volver a abrir la app, o desde el aviso naranja."
                        + (error == null ? "" : "\n\n" + error);
        TextView m = texto(msg, 16, GRIS, tTexto);
        m.setGravity(Gravity.CENTER);
        m.setLineSpacing(0, 1.25f);
        m.setPadding(0, dp(8), 0, dp(10));
        h.addView(m, lp(MP, WC));
        botonHoja(h, "Nueva entrega", PRINCIPAL, () -> {
            limpiarFormulario();
            volverHasta(0);
        });
        mostrarHoja(h, false);
        circulo.setScaleX(0f);
        circulo.setScaleY(0f);
        circulo.animate().scaleX(1f).scaleY(1f).setStartDelay(220).setDuration(420).setInterpolator(new OvershootInterpolator(2.5f)).start();
    }

    private void limpiarFormulario() {
        campoNombre.setText("");
        campoCorreo.setText("");
        campoOtros.setText("");
        for (FilaEpi f : filas) { f.marcada = false; pintarFila(f, false); }
        pintarContador();
        firma.borrar();
        pintarCabeceraEntrega();
        pintarAvisoPendientes();
    }

    /** Coloca en la hoja todas las filas configuradas y marca las entregadas. Los "otros" ocupan huecos libres. */
    private void colocarEpis(HojaEpi.Datos d, List<String> entregados, List<String> otros) {
        List<String> filasHoja = new ArrayList<>();
        for (String s : episConfigurados()) filasHoja.add(s.trim());
        List<String> pendientes = new ArrayList<>(otros);
        for (int i = 0; i < filasHoja.size() && !pendientes.isEmpty(); i++) {
            if (filasHoja.get(i).isEmpty()) filasHoja.set(i, pendientes.remove(0));
        }
        filasHoja.addAll(pendientes);
        for (int i = filasHoja.size() - 1; i >= 0 && filasHoja.size() > MAX_FILAS; i--) if (filasHoja.get(i).isEmpty()) filasHoja.remove(i);
        for (int i = filasHoja.size() - 1; i >= 0 && filasHoja.size() > MAX_FILAS; i--) {
            if (!entregados.contains(filasHoja.get(i)) && !otros.contains(filasHoja.get(i))) filasHoja.remove(i);
        }
        for (String f : filasHoja) {
            d.epis.add(f);
            d.marcados.add(!f.isEmpty() && (entregados.contains(f) || otros.contains(f)));
        }
    }

    private void escribirPdf(HojaEpi.Datos d, File destino) throws Exception {
        Bitmap logo = BitmapFactory.decodeResource(getResources(), R.drawable.logo_azvi);
        Typeface normal = Typeface.createFromAsset(getAssets(), "fuentes/Carlito-Regular.ttf");
        Typeface negrita = Typeface.createFromAsset(getAssets(), "fuentes/Carlito-Bold.ttf");
        HojaEpi hoja = new HojaEpi(logo, normal, negrita);
        PdfDocument doc = new PdfDocument();
        PdfDocument.Page p1 = doc.startPage(new PdfDocument.PageInfo.Builder(HojaEpi.ANCHO, HojaEpi.ALTO, 1).create());
        hoja.dibujarAnverso(p1.getCanvas(), d);
        doc.finishPage(p1);
        PdfDocument.Page p2 = doc.startPage(new PdfDocument.PageInfo.Builder(HojaEpi.ANCHO, HojaEpi.ALTO, 2).create());
        hoja.dibujarReverso(p2.getCanvas());
        doc.finishPage(p2);
        FileOutputStream out = new FileOutputStream(destino);
        try {
            doc.writeTo(out);
        } finally {
            out.close();
            doc.close();
        }
    }

    // ======================================================================
    // Envío al script de Google
    // ======================================================================
    private String urlScript() {
        String propia = prefs.getString("url", "");
        return propia.isEmpty() ? BuildConfig.SCRIPT_URL : propia;
    }

    private void reintentarPendientes(boolean avisar) {
        if (enviando) return;
        JSONArray en = leerLista("entregas");
        List<Integer> nums = new ArrayList<>();
        for (int i = 0; i < en.length(); i++) {
            JSONObject o = en.optJSONObject(i);
            if (!o.optBoolean("enviado")) nums.add(o.optInt("n"));
        }
        if (nums.isEmpty()) return;
        if (urlScript().isEmpty()) {
            if (avisar) aviso("Falta configurar el envío", "Todavía no está configurado el envío de correos.");
            return;
        }
        if (avisar) toast("Enviando…");
        enviarVarias(nums, 0, 0, avisar);
    }

    private void enviarVarias(final List<Integer> nums, final int i, final int fallos, final boolean avisar) {
        if (i >= nums.size()) {
            pintarAvisoPendientes();
            if (pHistorial.raiz.getVisibility() == View.VISIBLE) pintarHistorial();
            if (avisar) {
                if (fallos == 0) aviso("Todo enviado", "Se han enviado todas las entregas pendientes.");
                else aviso("Sin enviar", fallos == 1 ? "Una entrega sigue sin poder enviarse. Comprueba la conexión."
                        : fallos + " entregas siguen sin poder enviarse. Comprueba la conexión.");
            }
            return;
        }
        enviar(nums.get(i), error -> enviarVarias(nums, i + 1, fallos + (error == null ? 0 : 1), avisar));
    }

    private void reenviar(final int numero) {
        if (urlScript().isEmpty()) { aviso("Falta configurar el envío", "Todavía no está configurado el envío de correos."); return; }
        if (enviando) { toast("Hay otro envío en marcha"); return; }
        toast("Enviando…");
        enviar(numero, error -> {
            pintarAvisoPendientes();
            if (pHistorial.raiz.getVisibility() == View.VISIBLE) pintarHistorial();
            if (error == null) aviso("Enviado", "El recibí se ha enviado.");
            else aviso("No se ha podido enviar", error);
        });
    }

    private interface AlTerminar { void hecho(String error); }

    private void enviar(final int numero, final AlTerminar fin) {
        final JSONObject en = buscarEntrega(numero);
        if (en == null) { fin.hecho("No se encuentra la entrega"); return; }
        final String url = urlScript();
        final String seguridad = prefs.getString("seguridad", SEGURIDAD_INICIAL);
        final File pdf = new File(carpetaEntregas(), en.optString("archivo"));
        enviando = true;
        new Thread(() -> {
            String error;
            try {
                JSONObject cuerpo = new JSONObject();
                cuerpo.put("clave", CLAVE);
                cuerpo.put("correoTrabajador", en.optString("correo"));
                cuerpo.put("correoSeguridad", seguridad);
                cuerpo.put("asunto", "Entrega de EPIs - " + en.optString("nombre") + " - " + en.optString("fecha"));
                cuerpo.put("cuerpo", "Se adjunta el recibí de entrega de equipos de protección individual firmado por "
                        + en.optString("nombre") + " el " + en.optString("fecha") + ".\n\n"
                        + "EPIs entregados:\n- " + en.optString("epis").replace(", ", "\n- ") + "\n\n"
                        + "Obra nº " + NUMERO_OBRA + ".\n\nAzvi, S.A.");
                cuerpo.put("archivo", en.optString("archivo"));
                cuerpo.put("pdf", android.util.Base64.encodeToString(leerArchivo(pdf), android.util.Base64.NO_WRAP));
                JSONObject r = new JSONObject(post(url, cuerpo.toString()));
                error = r.optBoolean("ok") ? null : r.optString("error", "Respuesta desconocida");
            } catch (Exception ex) {
                error = "Sin conexión o dirección incorrecta (" + ex.getClass().getSimpleName() + ")";
            }
            final String err = error;
            handler.post(() -> {
                enviando = false;
                if (err == null) marcarEnviada(numero);
                fin.hecho(err);
            });
        }).start();
    }

    /** POST al script. Google responde con una redirección que hay que seguir con GET. */
    private static String post(String direccion, String json) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(direccion).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(false);
        c.setDoOutput(true);
        c.setRequestMethod("POST");
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        OutputStream os = c.getOutputStream();
        os.write(json.getBytes("UTF-8"));
        os.close();
        int code = c.getResponseCode();
        if (code >= 300 && code < 400) {
            String destino = c.getHeaderField("Location");
            c.disconnect();
            return get(destino);
        }
        return leer(c);
    }

    private static String get(String direccion) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(direccion).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(true);
        return leer(c);
    }

    private static String leer(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while (in != null && (n = in.read(buf)) > 0) b.write(buf, 0, n);
        if (in != null) in.close();
        c.disconnect();
        String s = b.toString("UTF-8");
        if (code >= 400 || !s.trim().startsWith("{")) throw new Exception("HTTP " + code);
        return s;
    }

    private void marcarEnviada(int numero) {
        JSONArray lista = leerLista("entregas");
        for (int i = 0; i < lista.length(); i++) {
            JSONObject o = lista.optJSONObject(i);
            if (o.optInt("n") == numero) try { o.put("enviado", true); } catch (Exception ignorada) { }
        }
        guardarLista("entregas", lista);
    }

    private JSONObject buscarEntrega(int numero) {
        JSONArray lista = leerLista("entregas");
        for (int i = lista.length() - 1; i >= 0; i--) {
            JSONObject o = lista.optJSONObject(i);
            if (o.optInt("n") == numero) return o;
        }
        return null;
    }

    // ======================================================================
    // Pantalla 3: historial
    // ======================================================================
    private void crearHistorial() {
        View atras = botonBarra(R.drawable.ic_volver, "Volver", v -> volver());
        pHistorial = crearPantalla("HISTORIAL", "Entregas", atras, null, false);
        LinearLayout c = pHistorial.contenido;

        LinearLayout stats = fila();
        statAnio = estadistica(stats, "Este año", true, BLANCO);
        statEnviadas = estadistica(stats, "Enviadas", false, VERDE);
        statPendientes = estadistica(stats, "Pendientes", false, NARANJA);
        c.addView(stats, lpArriba(MP, WC, 16));

        LinearLayout busca = fila();
        busca.setBackground(forma(BLANCO, BORDE, 1, 14));
        busca.setPadding(dp(14), 0, dp(6), 0);
        busca.addView(icono(R.drawable.ic_buscar, GRIS, 18));
        campoBuscar = new EditText(this);
        campoBuscar.setHint("Buscar trabajador");
        campoBuscar.setTypeface(tTexto);
        campoBuscar.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        campoBuscar.setTextColor(TEXTO);
        campoBuscar.setHintTextColor(0xFF8A95A5);
        campoBuscar.setBackground(null);
        campoBuscar.setSingleLine(true);
        campoBuscar.setPadding(dp(10), 0, 0, 0);
        campoBuscar.addTextChangedListener(new Vigia() {
            @Override public void afterTextChanged(Editable s) { pintarHistorial(); }
        });
        busca.addView(campoBuscar, new LinearLayout.LayoutParams(0, dp(50), 1));
        c.addView(busca, lpArriba(MP, dp(52), 14));

        listaHistorial = columna();
        c.addView(listaHistorial, lp(MP, WC));
    }

    private TextView estadistica(LinearLayout padre, String nombre, boolean destacada, int colorNumero) {
        LinearLayout t = columna();
        t.setPadding(dp(14), dp(12), dp(14), dp(12));
        t.setBackground(forma(destacada ? AZUL : BLANCO, 0, 0, 18));
        t.setElevation(destacada ? 0 : dp(1));
        TextView n = texto("0", 26, colorNumero, tTitulo);
        t.addView(n);
        t.addView(texto(nombre, 12, destacada ? AZUL_SUAVE : GRIS, tFuerte));
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, WC, 1);
        if (padre.getChildCount() < 2) l.rightMargin = dp(10);
        padre.addView(t, l);
        return n;
    }

    private void pintarHistorial() {
        listaHistorial.removeAllViews();
        JSONArray lista = leerLista("entregas");
        String anio = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        int nAnio = 0, nEnv = 0, nPen = 0;
        for (int i = 0; i < lista.length(); i++) {
            JSONObject o = lista.optJSONObject(i);
            if (o.optString("fecha").endsWith(anio)) nAnio++;
            if (o.optBoolean("enviado")) nEnv++; else nPen++;
        }
        statAnio.setText(String.valueOf(nAnio));
        statEnviadas.setText(String.valueOf(nEnv));
        statPendientes.setText(String.valueOf(nPen));

        String filtro = sinAcentos(campoBuscar.getText().toString().trim()).toLowerCase(Locale.ROOT);
        String grupo = null;
        int pintadas = 0;
        for (int i = lista.length() - 1; i >= 0; i--) {
            final JSONObject o = lista.optJSONObject(i);
            if (!filtro.isEmpty() && !sinAcentos(o.optString("nombre")).toLowerCase(Locale.ROOT).contains(filtro)) continue;
            String g = cabeceraFecha(o.optString("fecha"));
            if (!g.equals(grupo)) {
                grupo = g;
                TextView tg = texto(g, 12, GRIS, tFuerte);
                tg.setLetterSpacing(0.1f);
                tg.setPadding(dp(4), dp(20), 0, dp(2));
                listaHistorial.addView(tg);
            }
            listaHistorial.addView(tarjetaEntrega(o), lpArriba(MP, WC, 10));
            pintadas++;
        }
        if (pintadas == 0) {
            TextView t = texto(lista.length() == 0 ? "Todavía no hay entregas." : "No hay entregas con ese nombre.", 16, GRIS, tTexto);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(40), 0, 0);
            listaHistorial.addView(t, lp(MP, WC));
        }
    }

    private View tarjetaEntrega(final JSONObject o) {
        final boolean ok = o.optBoolean("enviado");
        final int numero = o.optInt("n");
        LinearLayout t = fila();
        t.setGravity(Gravity.TOP);
        t.setPadding(dp(16), dp(14), dp(16), dp(14));
        t.setBackground(conOnda(forma(BLANCO, ok ? 0 : NARANJA_BORDE, 1, 18), 0x221B4E91));
        t.setElevation(dp(1));
        t.setClickable(true);
        t.setOnClickListener(v -> opcionesEntrega(o));

        t.addView(avatar(o.optString("nombre"), ok ? AZUL : NARANJA, ok ? AZUL_CLARO : NARANJA_CLARO));

        LinearLayout col = columna();
        col.setPadding(dp(12), 0, 0, 0);
        LinearLayout f1 = fila();
        TextView nom = texto(o.optString("nombre"), 16, TEXTO, tFuerte);
        nom.setSingleLine(true);
        nom.setEllipsize(TextUtils.TruncateAt.END);
        f1.addView(nom, new LinearLayout.LayoutParams(0, WC, 1));
        col.addView(f1, lp(MP, WC));
        TextView ep = texto(o.optString("epis"), 14, GRIS, tTexto);
        ep.setLineSpacing(0, 1.2f);
        ep.setPadding(0, dp(3), 0, dp(4));
        col.addView(ep);

        LinearLayout f2 = fila();
        f2.addView(icono(ok ? R.drawable.ic_check : R.drawable.ic_reloj, ok ? VERDE : NARANJA, 14));
        TextView est = texto(ok ? "Enviado" : "Sin enviar", 13, ok ? VERDE : NARANJA, tFuerte);
        est.setPadding(dp(5), 0, 0, 0);
        f2.addView(est, new LinearLayout.LayoutParams(0, WC, 1));
        if (!ok) {
            TextView re = texto("Reintentar", 14, BLANCO, tFuerte);
            re.setGravity(Gravity.CENTER);
            re.setPadding(dp(14), 0, dp(14), 0);
            re.setBackground(conOnda(forma(NARANJA, 0, 0, 10), 0x33FFFFFF));
            re.setOnClickListener(v -> reenviar(numero));
            f2.addView(re, lp(WC, dp(40)));
        }
        col.addView(f2, lp(MP, WC));
        t.addView(col, new LinearLayout.LayoutParams(0, WC, 1));
        return t;
    }

    private String cabeceraFecha(String fecha) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date d = f.parse(fecha);
            if (fecha.equals(hoy())) return "HOY";
            Calendar ayer = Calendar.getInstance();
            ayer.add(Calendar.DAY_OF_YEAR, -1);
            if (fecha.equals(f.format(ayer.getTime()))) return "AYER";
            Locale es = new Locale("es", "ES");
            Calendar c = Calendar.getInstance();
            c.setTime(d);
            boolean esteAnio = c.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR);
            return new SimpleDateFormat(esteAnio ? "EEEE d 'de' MMMM" : "EEEE d 'de' MMMM 'de' yyyy", es).format(d).toUpperCase(es);
        } catch (Exception ex) {
            return fecha;
        }
    }

    private void opcionesEntrega(final JSONObject o) {
        final int numero = o.optInt("n");
        LinearLayout h = nuevaHoja(o.optString("nombre"), o.optString("fecha") + "\n" + o.optString("epis"));
        botonHoja(h, "Ver o compartir el PDF", SECUNDARIO, () -> verPdf(o.optString("archivo")));
        botonHoja(h, o.optBoolean("enviado") ? "Volver a enviar por correo" : "Enviar ahora", SECUNDARIO, () -> reenviar(numero));
        botonHoja(h, "Eliminar entrega", PELIGRO, () -> confirmarBorrado(numero, o.optString("archivo")));
        mostrarHoja(h, true);
    }

    private void verPdf(String archivo) {
        File f = new File(carpetaEntregas(), archivo);
        if (!f.exists()) { aviso("No encontrado", "El PDF ya no está en el móvil."); return; }
        Uri uri = Uri.parse("content://" + ProveedorPdf.AUTORIDAD + "/" + Uri.encode(archivo));
        Intent ver = new Intent(Intent.ACTION_VIEW);
        ver.setDataAndType(uri, "application/pdf");
        ver.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent compartir = new Intent(Intent.ACTION_SEND);
        compartir.setType("application/pdf");
        compartir.putExtra(Intent.EXTRA_STREAM, uri);
        compartir.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent elegir = Intent.createChooser(ver, "Abrir el PDF con…");
        elegir.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{compartir});
        try {
            startActivity(elegir);
        } catch (Exception ex) {
            aviso("Sin visor de PDF", "No hay ninguna app para abrir PDFs en el móvil.");
        }
    }

    private void confirmarBorrado(final int numero, final String archivo) {
        LinearLayout h = nuevaHoja("¿Eliminar esta entrega?",
                "Se borra del móvil. Los correos ya enviados y la copia guardada en Drive no se tocan.");
        botonHoja(h, "Eliminar", PELIGRO, () -> {
            JSONArray lista = leerLista("entregas"), nueva = new JSONArray();
            for (int i = 0; i < lista.length(); i++) if (lista.optJSONObject(i).optInt("n") != numero) nueva.put(lista.optJSONObject(i));
            guardarLista("entregas", nueva);
            //noinspection ResultOfMethodCallIgnored
            new File(carpetaEntregas(), archivo).delete();
            pintarHistorial();
            pintarAvisoPendientes();
            toast("Entrega eliminada");
        });
        botonHoja(h, "Cancelar", SUAVE, null);
        mostrarHoja(h, true);
    }

    // ======================================================================
    // Pantalla 4: ajustes
    // ======================================================================
    private void crearAjustes() {
        View atras = botonBarra(R.drawable.ic_volver, "Volver", v -> {
            if (ajCambios) preguntarGuardarAjustes(); else volver();
        });
        pAjustes = crearPantalla("CONFIGURACIÓN", "Ajustes", atras, null, true);
        LinearLayout c = pAjustes.contenido;

        // --- Envío de correos ---
        LinearLayout envio = tarjeta(c);
        ajEstado = texto("", 13, GRIS, tFuerte);
        ajEstado.setPadding(dp(10), dp(5), dp(10), dp(5));
        encabezado(envio, R.drawable.ic_correo, "Envío de correos", ajEstado);
        etiqueta(envio, "Correo del técnico de seguridad");
        ajSeguridad = campo(envio, "correo@azvi.es", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        Drawable escudo = getResources().getDrawable(R.drawable.ic_escudo, getTheme()).mutate();
        escudo.setTint(AZUL);
        escudo.setBounds(0, 0, dp(18), dp(18));
        ajSeguridad.setCompoundDrawablesRelative(escudo, null, null, null);
        ajSeguridad.setCompoundDrawablePadding(dp(10));
        ajSeguridad.addTextChangedListener(new Vigia() {
            @Override public void afterTextChanged(Editable s) { if (!ajCargando) ajCambios = true; }
        });
        Boton comprobar = boton("Comprobar conexión", R.drawable.ic_refrescar, false, SECUNDARIO);
        comprobar.vista.setOnClickListener(v -> comprobarConexion());
        envio.addView(comprobar.vista, lpArriba(MP, dp(48), 14));

        // Texto discreto: manteniéndolo pulsado 3 s se puede cambiar la dirección del script
        ajUrlTexto = texto("Dirección de script", 13, GRIS_CLARO, tMedio);
        ajUrlTexto.setGravity(Gravity.CENTER);
        ajUrlTexto.setPadding(0, dp(14), 0, dp(2));
        abrirEditorUrl = this::editarUrl;
        ajUrlTexto.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    handler.postDelayed(abrirEditorUrl, PULSACION_URL_MS);
                    v.animate().alpha(0.3f).setDuration(PULSACION_URL_MS).start();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(abrirEditorUrl);
                    v.animate().cancel();
                    v.setAlpha(1f);
                    return true;
                default:
                    return true;
            }
        });
        envio.addView(ajUrlTexto, lp(MP, WC));

        // --- Datos de la hoja ---
        LinearLayout hoja = tarjeta(c);
        encabezado(hoja, R.drawable.ic_documento, "Datos de la hoja", null);
        etiqueta(hoja, "Obra");
        ajObra = campo(hoja, "Obra", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        ajObra.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        ajObra.addTextChangedListener(new Vigia() {
            @Override public void afterTextChanged(Editable s) { if (!ajCargando) ajCambios = true; }
        });

        // --- Lista de EPIs ---
        LinearLayout epis = tarjeta(c);
        ajCuentaEpis = texto("", 13, GRIS, tFuerte);
        encabezado(epis, R.drawable.ic_casco, "Lista de EPIs", ajCuentaEpis);
        TextView ay = texto("Arrastra desde los puntos para cambiar el orden. Toca un EPI para cambiarle el nombre. "
                + "Los 10 primeros van a la columna izquierda de la hoja.", 12, GRIS, tTexto);
        ay.setLineSpacing(0, 1.2f);
        ay.setPadding(0, dp(8), 0, dp(4));
        epis.addView(ay);
        ajListaEpis = columna();
        epis.addView(ajListaEpis, lp(MP, WC));
        TextView anadir = texto("+  Añadir EPI", 15, AZUL, tFuerte);
        anadir.setGravity(Gravity.CENTER);
        GradientDrawable fa = forma(0xFFF7FAFE, 0, 0, 12);
        fa.setStroke(dp(1), AZUL, dp(5), dp(4));
        anadir.setBackground(conOnda(fa, 0x221B4E91));
        anadir.setOnClickListener(v -> anadirEpi());
        epis.addView(anadir, lpArriba(MP, dp(48), 12));

        // --- Trabajadores guardados ---
        LinearLayout tr = tarjeta(c);
        tr.setPadding(dp(18), dp(8), dp(12), dp(8));
        LinearLayout ft = fila();
        ft.setMinimumHeight(dp(56));
        ft.setClickable(true);
        ft.setOnClickListener(v -> ir(pTrabajadores));
        ft.addView(cuadroIcono(R.drawable.ic_usuarios));
        LinearLayout tt = columna();
        tt.setPadding(dp(10), 0, 0, 0);
        tt.addView(texto("Trabajadores guardados", 17, TEXTO, tTituloMedio));
        cuentaTrabajadores = texto("", 13, GRIS, tTexto);
        tt.addView(cuentaTrabajadores);
        ft.addView(tt, new LinearLayout.LayoutParams(0, WC, 1));
        ft.addView(icono(R.drawable.ic_siguiente, GRIS, 20));
        tr.addView(ft, lp(MP, WC));

        // --- Firma discreta del autor ---
        TextView v1 = texto(VERSION, 12, GRIS_CLARO, tTexto);
        v1.setGravity(Gravity.CENTER);
        v1.setPadding(0, dp(22), 0, 0);
        c.addView(v1, lp(MP, WC));
        TextView v2 = texto(FIRMA_AUTOR, 12, GRIS_CLARO, tTexto);
        v2.setGravity(Gravity.CENTER);
        c.addView(v2, lp(MP, WC));

        Boton guardar = boton("Guardar ajustes", R.drawable.ic_check, false, PRINCIPAL);
        guardar.vista.setOnClickListener(v -> guardarAjustes());
        pAjustes.barra.addView(guardar.vista, lp(MP, dp(58)));
    }

    private void actualizarCuentaTrabajadores() {
        int n = leerLista("trabajadores").length();
        cuentaTrabajadores.setText(n == 1 ? "1 guardado" : n + " guardados");
    }

    private void cargarAjustes() {
        ajCargando = true;
        ajSeguridad.setText(prefs.getString("seguridad", SEGURIDAD_INICIAL));
        ajObra.setText(prefs.getString("obra", OBRA_INICIAL));
        ajEpis.clear();
        ajEpis.addAll(episConfigurados());
        pintarEditorEpis();
        actualizarCuentaTrabajadores();
        ajCargando = false;
        ajCambios = false;
        comprobarConexion();
    }

    private void estadoConexion(int estado) {
        // 0 comprobando · 1 conectado · 2 sin conexión · 3 sin configurar
        String[] textos = {"Comprobando…", "●  Conectado", "●  Sin conexión", "Sin configurar"};
        int[] colores = {GRIS, VERDE, NARANJA, NARANJA};
        int[] fondos = {FONDO, VERDE_CLARO, NARANJA_CLARO, NARANJA_CLARO};
        ajEstado.setText(textos[estado]);
        ajEstado.setTextColor(colores[estado]);
        ajEstado.setBackground(forma(fondos[estado], 0, 0, 999));
    }

    private void comprobarConexion() {
        final String url = urlScript();
        if (url.isEmpty()) { estadoConexion(3); return; }
        estadoConexion(0);
        new Thread(() -> {
            boolean ok;
            try { ok = "epis".equals(new JSONObject(get(url)).optString("servicio")); }
            catch (Exception ex) { ok = false; }
            final boolean r = ok;
            handler.post(() -> estadoConexion(r ? 1 : 2));
        }).start();
    }

    private void editarUrl() {
        ajUrlTexto.animate().cancel();
        ajUrlTexto.setAlpha(1f);
        LinearLayout h = nuevaHoja("Dirección de script",
                "Es la dirección del script de Google que envía los correos. No la cambies si no sabes lo que es.");
        final EditText e = new EditText(this);
        prepararCampo(e, "https://script.google.com/macros/s/…/exec", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        e.setText(urlScript());
        h.addView(e, lpArriba(MP, WC, 12));
        botonHoja(h, "Guardar dirección", PRINCIPAL, () -> {
            String url = e.getText().toString().trim();
            if (!url.isEmpty() && !url.startsWith("https://")) { aviso("Dirección no válida", "Tiene que empezar por https://"); return; }
            if (url.equals(BuildConfig.SCRIPT_URL)) url = "";
            prefs.edit().putString("url", url).apply();
            comprobarConexion();
            toast("Dirección guardada");
        });
        if (!BuildConfig.SCRIPT_URL.isEmpty()) {
            botonHoja(h, "Volver a la dirección original", SECUNDARIO, () -> {
                prefs.edit().remove("url").apply();
                comprobarConexion();
                toast("Dirección original restablecida");
            });
        }
        botonHoja(h, "Cancelar", SUAVE, null);
        mostrarHoja(h, true);
    }

    // --- Editor de la lista de EPIs ---
    private void pintarEditorEpis() {
        ajListaEpis.removeAllViews();
        for (int i = 0; i < ajEpis.size(); i++) {
            final int pos = i;
            final String nombre = ajEpis.get(i).trim();
            final LinearLayout f = fila();
            f.setMinimumHeight(dp(50));
            f.setBackgroundColor(BLANCO);

            FrameLayout zonaAsa = new FrameLayout(this);
            zonaAsa.addView(icono(R.drawable.ic_asa, BORDE_FUERTE, 22), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
            zonaAsa.setContentDescription("Mover");
            zonaAsa.setOnTouchListener((v, e) -> arrastrar(f, pos, e));
            f.addView(zonaAsa, lp(dp(40), dp(50)));

            TextView t = texto(nombre.isEmpty() ? "Fila vacía" : nombre, 15, nombre.isEmpty() ? GRIS_CLARO : TEXTO, tTexto);
            if (nombre.isEmpty()) t.setTypeface(tTexto, Typeface.ITALIC);
            t.setPadding(dp(4), dp(10), dp(8), dp(10));
            t.setOnClickListener(v -> renombrarEpi(pos));
            f.addView(t, new LinearLayout.LayoutParams(0, WC, 1));

            FrameLayout quitar = new FrameLayout(this);
            quitar.setBackground(conOnda(forma(BLANCO, 0, 0, 10), 0x22B3261E));
            quitar.setContentDescription("Quitar");
            quitar.addView(icono(R.drawable.ic_papelera, GRIS_CLARO, 18), new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER));
            quitar.setOnClickListener(v -> {
                ajEpis.remove(pos);
                ajCambios = true;
                pintarEditorEpis();
            });
            f.addView(quitar, lp(dp(44), dp(44)));

            ajListaEpis.addView(f, lp(MP, WC));
            if (i < ajEpis.size() - 1) {
                View sep = new View(this);
                sep.setBackgroundColor(0xFFEEF2F6);
                ajListaEpis.addView(sep, lp(MP, 1));
            }
        }
        ajCuentaEpis.setText(ajEpis.size() + " de " + MAX_FILAS);
    }

    private boolean arrastrar(View f, int pos, MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                arrastreY0 = e.getRawY();
                f.setElevation(dp(8));
                f.setBackground(forma(BLANCO, BORDE, 1, 10));
                f.getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_MOVE:
                f.setTranslationY(e.getRawY() - arrastreY0);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                float dy = e.getRawY() - arrastreY0;
                int alto = Math.max(1, f.getHeight() + 1);
                int destino = Math.max(0, Math.min(ajEpis.size() - 1, pos + Math.round(dy / alto)));
                f.setTranslationY(0);
                f.setElevation(0);
                if (destino != pos) {
                    String s = ajEpis.remove(pos);
                    ajEpis.add(destino, s);
                    ajCambios = true;
                }
                pintarEditorEpis();
                return true;
            default:
                return true;
        }
    }

    private void renombrarEpi(final int pos) {
        pedirTexto("Cambiar EPI", "Deja el texto en blanco para que sea una fila vacía en la hoja.", ajEpis.get(pos).trim(),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES, "Guardar", valor -> {
                    ajEpis.set(pos, valor);
                    ajCambios = true;
                    pintarEditorEpis();
                });
    }

    private void anadirEpi() {
        if (ajEpis.size() >= MAX_FILAS) { aviso("Lista llena", "La hoja tiene sitio para " + MAX_FILAS + " filas como máximo."); return; }
        LinearLayout h = nuevaHoja("Añadir EPI", null);
        final EditText e = new EditText(this);
        prepararCampo(e, "Nombre del EPI", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        h.addView(e, lpArriba(MP, WC, 12));
        botonHoja(h, "Añadir", PRINCIPAL, () -> {
            String s = e.getText().toString().trim();
            if (s.isEmpty()) return;
            ajEpis.add(s);
            ajCambios = true;
            pintarEditorEpis();
        });
        botonHoja(h, "Añadir una fila vacía", SECUNDARIO, () -> {
            ajEpis.add("");
            ajCambios = true;
            pintarEditorEpis();
        });
        botonHoja(h, "Cancelar", SUAVE, null);
        mostrarHoja(h, true);
        mostrarTeclado(e);
    }

    private void guardarAjustes() {
        String seg = ajSeguridad.getText().toString().trim();
        if (!Patterns.EMAIL_ADDRESS.matcher(seg).matches()) {
            aviso("Correo no válido", "Revisa el correo del técnico de seguridad.");
            return;
        }
        while (!ajEpis.isEmpty() && ajEpis.get(ajEpis.size() - 1).trim().isEmpty()) ajEpis.remove(ajEpis.size() - 1);
        prefs.edit()
                .putString("seguridad", seg)
                .putString("obra", ajObra.getText().toString().trim())
                .putString("epis", unir(ajEpis, "\n"))
                .apply();
        ajCambios = false;
        toast("Ajustes guardados");
        volver();
    }

    private void preguntarGuardarAjustes() {
        LinearLayout h = nuevaHoja("¿Guardar los cambios?", "Has cambiado algunos ajustes.");
        botonHoja(h, "Guardar", PRINCIPAL, this::guardarAjustes);
        botonHoja(h, "Descartar cambios", PELIGRO, () -> { ajCambios = false; volver(); });
        botonHoja(h, "Seguir editando", SUAVE, null);
        mostrarHoja(h, true);
    }

    // ======================================================================
    // Pantalla 5: trabajadores guardados
    // ======================================================================
    private void crearTrabajadores() {
        View atras = botonBarra(R.drawable.ic_volver, "Volver", v -> volver());
        pTrabajadores = crearPantalla("AJUSTES", "Trabajadores", atras, null, false);
        listaTrabajadores = columna();
        pTrabajadores.contenido.addView(listaTrabajadores, lp(MP, WC));
    }

    private void pintarTrabajadores() {
        listaTrabajadores.removeAllViews();
        JSONArray tr = leerLista("trabajadores");
        if (tr.length() == 0) {
            TextView t = texto("Se guardan solos al hacer la primera entrega de cada trabajador.", 16, GRIS, tTexto);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(10), dp(40), dp(10), 0);
            listaTrabajadores.addView(t, lp(MP, WC));
        }
        for (int i = 0; i < tr.length(); i++) {
            final JSONObject o = tr.optJSONObject(i);
            LinearLayout f = fila();
            f.setPadding(dp(16), dp(12), dp(12), dp(12));
            f.setBackground(conOnda(forma(BLANCO, 0, 0, 18), 0x221B4E91));
            f.setElevation(dp(1));
            f.setClickable(true);
            f.setOnClickListener(v -> editarTrabajador(o.optString("nombre"), o.optString("correo")));
            f.addView(avatar(o.optString("nombre"), AZUL, AZUL_CLARO));
            LinearLayout col = columna();
            col.setPadding(dp(12), 0, 0, 0);
            col.addView(texto(o.optString("nombre"), 16, TEXTO, tFuerte));
            String c = o.optString("correo");
            col.addView(texto(c.isEmpty() ? "Sin correo" : c, 14, GRIS, tTexto));
            f.addView(col, new LinearLayout.LayoutParams(0, WC, 1));
            f.addView(icono(R.drawable.ic_siguiente, GRIS, 20));
            listaTrabajadores.addView(f, lpArriba(MP, WC, 10));
        }
    }

    private void editarTrabajador(final String nombre, String correo) {
        LinearLayout h = nuevaHoja(nombre, "Correo del trabajador");
        final EditText e = new EditText(this);
        prepararCampo(e, "nombre@correo.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        e.setText(correo);
        h.addView(e, lpArriba(MP, WC, 12));
        botonHoja(h, "Guardar", PRINCIPAL, () -> {
            String c = e.getText().toString().trim();
            if (!c.isEmpty() && !Patterns.EMAIL_ADDRESS.matcher(c).matches()) { aviso("Correo no válido", "Revisa el correo."); return; }
            guardarTrabajador(nombre, c, true);
            pintarTrabajadores();
        });
        botonHoja(h, "Borrar trabajador", PELIGRO, () -> {
            borrarTrabajador(nombre);
            pintarTrabajadores();
        });
        botonHoja(h, "Cancelar", SUAVE, null);
        mostrarHoja(h, true);
    }

    // ======================================================================
    // Datos guardados
    // ======================================================================
    private List<String> episConfigurados() {
        List<String> l = new ArrayList<>();
        String s = prefs.getString("epis", EPIS_INICIALES);
        if (s.isEmpty()) return l;
        Collections.addAll(l, s.split("\n", -1));
        return l;
    }

    private JSONArray leerLista(String clave) {
        try { return new JSONArray(prefs.getString(clave, "[]")); }
        catch (Exception ex) { return new JSONArray(); }
    }

    private void guardarLista(String clave, JSONArray a) {
        prefs.edit().putString(clave, a.toString()).apply();
    }

    private String correoDe(String nombre) {
        JSONArray tr = leerLista("trabajadores");
        for (int i = 0; i < tr.length(); i++) {
            JSONObject o = tr.optJSONObject(i);
            if (o.optString("nombre").equalsIgnoreCase(nombre.trim())) return o.optString("correo");
        }
        return null;
    }

    private void recordarTrabajador(String nombre, String correo) {
        guardarTrabajador(nombre, correo, false);
    }

    /** Guarda o actualiza un trabajador. Si no se fuerza, un correo vacío no borra el que ya tuviera. */
    private void guardarTrabajador(String nombre, String correo, boolean forzar) {
        JSONArray tr = leerLista("trabajadores"), nueva = new JSONArray();
        try {
            boolean puesto = false;
            List<JSONObject> l = new ArrayList<>();
            for (int i = 0; i < tr.length(); i++) {
                JSONObject o = tr.optJSONObject(i);
                if (o.optString("nombre").equalsIgnoreCase(nombre)) {
                    if (puesto) continue;
                    o.put("nombre", nombre);
                    if (forzar || !correo.isEmpty()) o.put("correo", correo);
                    puesto = true;
                }
                l.add(o);
            }
            if (!puesto) {
                JSONObject o = new JSONObject();
                o.put("nombre", nombre);
                o.put("correo", correo);
                l.add(o);
            }
            Collections.sort(l, (a, b) -> a.optString("nombre").compareToIgnoreCase(b.optString("nombre")));
            for (JSONObject o : l) nueva.put(o);
            guardarLista("trabajadores", nueva);
        } catch (Exception ignorada) { }
    }

    private void borrarTrabajador(String nombre) {
        JSONArray tr = leerLista("trabajadores"), nueva = new JSONArray();
        for (int i = 0; i < tr.length(); i++) if (!tr.optJSONObject(i).optString("nombre").equals(nombre)) nueva.put(tr.optJSONObject(i));
        guardarLista("trabajadores", nueva);
    }

    private File carpetaEntregas() {
        File f = new File(getFilesDir(), "entregas");
        //noinspection ResultOfMethodCallIgnored
        f.mkdirs();
        return f;
    }

    private static byte[] leerArchivo(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        in.close();
        return b.toByteArray();
    }

    private static String hoy() {
        return new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
    }

    private static String sinAcentos(String s) {
        return Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }

    private static String unir(List<String> l, String sep) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < l.size(); i++) { if (i > 0) b.append(sep); b.append(l.get(i)); }
        return b.toString();
    }

    /** TextWatcher con solo afterTextChanged. */
    private abstract static class Vigia implements TextWatcher {
        @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
        @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
    }

    // ======================================================================
    // Contenedor que coloca etiquetas en varias filas (EPIs del resumen)
    // ======================================================================
    static class Fluir extends ViewGroup {
        private final int hueco;

        Fluir(Context c, int hueco) {
            super(c);
            this.hueco = hueco;
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int ancho = MeasureSpec.getSize(wSpec);
            int x = 0, y = 0, altoFila = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View v = getChildAt(i);
                v.measure(MeasureSpec.makeMeasureSpec(ancho, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
                if (x > 0 && x + v.getMeasuredWidth() > ancho) { x = 0; y += altoFila + hueco; altoFila = 0; }
                x += v.getMeasuredWidth() + hueco;
                altoFila = Math.max(altoFila, v.getMeasuredHeight());
            }
            setMeasuredDimension(ancho, y + altoFila);
        }

        @Override
        protected void onLayout(boolean cambiado, int l, int t, int r, int b) {
            int ancho = r - l, x = 0, y = 0, altoFila = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View v = getChildAt(i);
                if (x > 0 && x + v.getMeasuredWidth() > ancho) { x = 0; y += altoFila + hueco; altoFila = 0; }
                v.layout(x, y, x + v.getMeasuredWidth(), y + v.getMeasuredHeight());
                x += v.getMeasuredWidth() + hueco;
                altoFila = Math.max(altoFila, v.getMeasuredHeight());
            }
        }
    }

    // ======================================================================
    // Recuadro de firma
    // ======================================================================
    static class Firma extends View {
        private final Path trazo = new Path();
        private final Paint tinta = new Paint(Paint.ANTI_ALIAS_FLAG), pista = new Paint(Paint.ANTI_ALIAS_FLAG), linea = new Paint();
        private final RectF limites = new RectF();
        private boolean vacia = true;
        private float ux, uy;
        private final float d;

        Firma(Context c, Typeface letra) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            tinta.setColor(TINTA);
            tinta.setStyle(Paint.Style.STROKE);
            tinta.setStrokeWidth(2.8f * d);
            tinta.setStrokeCap(Paint.Cap.ROUND);
            tinta.setStrokeJoin(Paint.Join.ROUND);
            pista.setColor(GRIS_CLARO);
            pista.setTextSize(13 * d);
            pista.setTypeface(letra);
            linea.setColor(BORDE);
            linea.setStrokeWidth(d);
        }

        boolean vacia() { return vacia; }

        void borrar() {
            trazo.reset();
            vacia = true;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            float base = getHeight() - 38 * d;
            c.drawLine(20 * d, base, getWidth() - 20 * d, base, linea);
            if (vacia) c.drawText("Firma con el dedo", 22 * d, getHeight() - 14 * d, pista);
            c.drawPath(trazo, tinta);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX(), y = e.getY();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);   // que no se mueva la pantalla al firmar
                    trazo.moveTo(x, y);
                    trazo.lineTo(x + 0.1f, y);
                    ux = x;
                    uy = y;
                    vacia = false;
                    break;
                case MotionEvent.ACTION_MOVE:
                    for (int i = 0; i < e.getHistorySize(); i++) punto(e.getHistoricalX(i), e.getHistoricalY(i));
                    punto(x, y);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    getParent().requestDisallowInterceptTouchEvent(false);
                    break;
                default:
                    break;
            }
            invalidate();
            return true;
        }

        private void punto(float x, float y) {
            trazo.quadTo(ux, uy, (x + ux) / 2, (y + uy) / 2);
            ux = x;
            uy = y;
        }

        /** La firma recortada a su tamaño, con fondo transparente. */
        Bitmap recorte() {
            if (vacia) return null;
            trazo.computeBounds(limites, true);
            float m = tinta.getStrokeWidth() * 2;
            int l = (int) Math.max(0, limites.left - m), t = (int) Math.max(0, limites.top - m);
            int r = (int) Math.min(getWidth(), limites.right + m), b = (int) Math.min(getHeight(), limites.bottom + m);
            if (r - l < 2 || b - t < 2) { l = 0; t = 0; r = getWidth(); b = getHeight(); }
            Bitmap bmp = Bitmap.createBitmap(r - l, b - t, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            c.translate(-l, -t);
            c.drawPath(trazo, tinta);
            return bmp;
        }
    }
}
