package es.epis.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.ArrayList;
import java.util.List;

/**
 * Dibuja las dos caras del Mod. 335 (Entrega de EPIs) en un lienzo A4 de 595 x 842 puntos.
 * Las medidas copian las del Word original de Azvi.
 */
public class HojaEpi {

    public static final int ANCHO = 595, ALTO = 842;

    // Medidas sacadas del PDF del Word original (puntos)
    private static final float X0 = 84.5f, X1 = 560.8f;
    private static final float LOGO_DER = 185.1f;              // fin de la celda del logo
    public static final int FILAS = 10;                        // filas de EPIs por columna
    private static final float T = 14f, INTERL = 17.1f;        // letra de los textos e interlineado
    private static final float TX0 = 94.5f, TX1 = 550.4f;      // márgenes de los párrafos

    public static final String PIE = "Mod. 335, ES. 02/18, Rev. 3";

    public static final String TEXTO_RECIBI =
            "Por la presente declaro haber recibido de la Empresa AZVI, S.A. los equipos de protección "
            + "individual necesarios para el desempeño de mis funciones que a continuación se detallan:";
    public static final String TEXTO_DOCUMENTACION =
            "Los EPI’s entregados incluyen la documentación informativa proporcionada por el fabricante. "
            + "Asimismo al dorso se informa de las normas UNE de referencia del equipo así como de la "
            + "categoría del riesgo a cubrir.";
    public static final String TEXTO_DECLARO =
            "De igual modo, declaro; que he recibido la información sobre los riesgos contra los que protegen, "
            + "así como de las actividades u ocasiones en las que deben utilizarse y la formación sobre la "
            + "forma correcta de utilizarlos y mantenerlos.";
    public static final String TEXTO_CONSTE = "Y para que así conste, firmo el presente documento.";
    public static final String TEXTO_DORSO =
            "A título informativo se hace referencia para cada Equipo de protección individual a la norma "
            + "UNE de aplicación así como a su categoría en función del riesgo a cubrir.";

    public static final String[][] NORMAS = {
            {"Casco de seguridad", "UNE 397:2012  / UNE 812:2012", "CAT II"},
            {"Mono o buzo de trabajo", "UNE 13688: 2013 / UNE 20471:2013", "CAT II"},
            {"Botas de seguridad", "UNE 20344:2012 / UNE 20345/2012", "CAT II"},
            {"Botas impermeables", "UNE 20344:2012 / UNE 20345/2012", "CAT II"},
            {"Chaleco de alta visibilidad", "UNE 13688: 2013 / UNE 20471:2013", "CAT II"},
            {"Guantes de cuero", "UNE 420:04+A1:2010 / UNE 388: 2004", "CAT II"},
            {"Guantes de goma finos", "UNE 420:04+A1:2010 / UNE 388: 2004 / UNE 374-3:04", "CAT III"},
            {"Traje de agua", "UNE 13688: 2013 / UNE 343:2004+A1:2008", "CAT I"},
            {"Mascarilla antipolvo", "UNE 149:2001+A1:2010", "--"},
            {"Gafas antiproyecciones", "UNE-EN 166:2002", "CAT. II"},
            {"Cinturón de seguridad de sujeción", "UNE EN 358: 2000", "CAT. III"},
            {"Protectores auditivos", "UNE 352- 1: 2003 / UNE 352- 3: 2003", "CAT II"},
            {"Gafas soldadura y oxicorte", "UNE 379:2004+A1:2010 / UNE 175:97 / UNE 169:2003 / UNE 166/2002", "CAT II"},
            {"Arnés anticaída", "UNE-EN 361: 2002", "CAT. III"},
            {"Cuerda con Cabo doble", "UNE EN 354\nUNE EN 358", "CAT.III"},
            {"Ganchos", "UNE EN 362", "CAT III"},
            {"Mosquetones", "UNE EN 362", "CAT III"},
            {"Absorbedor de energía", "UNE EN 355", "CAT III"},
            {"Casco con barbuquejo", "UNE EN 397", "CAT III"},
    };

    /** Lo que se rellena en cada entrega. */
    public static class Datos {
        public String obra = "", numero = "", nombre = "", fecha = "";
        public List<String> epis = new ArrayList<>();        // todas las filas de la hoja, en orden
        public List<Boolean> marcados = new ArrayList<>();   // true = entregado (lleva X)
        public Bitmap firma;                                  // puede ser null
    }

    private final Bitmap logo;
    private final Typeface normal, negrita;
    private final Paint linea, texto;

    /** Las fuentes son Carlito (mismas medidas que Calibri, la del Word). */
    public HojaEpi(Bitmap logo, Typeface normal, Typeface negrita) {
        this.logo = logo;
        this.normal = normal;
        this.negrita = negrita;
        linea = new Paint();
        linea.setColor(Color.BLACK);
        linea.setStyle(Paint.Style.STROKE);
        linea.setStrokeWidth(0.75f);
        linea.setAntiAlias(true);
        texto = new Paint();
        texto.setColor(Color.BLACK);
        texto.setAntiAlias(true);
        texto.setFilterBitmap(true);
    }

    // ======================================================================
    // Cara 1: el recibí
    // ======================================================================
    public void dibujarAnverso(Canvas c, Datos d) {
        cabecera(c, "ENTREGA EQUIPOS DE PROTECCIÓN INDIVIDUAL");

        // --- Obra y número ---
        caja(c, 112.3f, 138.3f);
        fuente(16f, false);
        c.drawText("Obra:", 86f, 128f, texto);
        float tam = 12f;
        fuente(tam, false);
        while (tam > 6 && texto.measureText(d.obra) > 505 - 130) { tam -= 0.25f; fuente(tam, false); }
        c.drawText(d.obra, 129.9f, 128.5f, texto);
        c.drawLine(122f, 131.7f, 509f, 131.7f, linea);
        fuente(10f, false);
        c.drawText("Nº", 512.9f, 129.5f, texto);
        fuente(12f, false);
        c.drawText(d.numero, 557f - texto.measureText(d.numero), 128.5f, texto);
        c.drawLine(529f, 131.7f, 559f, 131.7f, linea);

        // --- Texto de recibí ---
        caja(c, 138.3f, 214.1f);
        parrafo(c, TEXTO_RECIBI, 164.1f);

        // --- Tabla de EPIs: 2 columnas de 10 filas ---
        float filaY0 = 214.1f, alto = 23.6f, filaY1 = filaY0 + FILAS * alto;
        float[] cols = {X0, 297.2f, 322.7f, 535.3f, X1};
        for (int i = 0; i <= FILAS; i++) c.drawLine(X0, filaY0 + i * alto, X1, filaY0 + i * alto, linea);
        for (float x : cols) c.drawLine(x, filaY0, x, filaY1, linea);
        for (int i = 0; i < d.epis.size() && i < FILAS * 2; i++) {
            int col = i / FILAS, fila = i % FILAS;
            float yb = filaY0 + fila * alto + 16.8f;
            float xt = col == 0 ? 86f : 324.2f;
            float ancho = (col == 0 ? cols[1] : cols[3]) - xt - 1.5f;
            String nombre = d.epis.get(i);
            float t = T;
            fuente(t, false);
            while (t > 7 && texto.measureText(nombre) > ancho) { t -= 0.25f; fuente(t, false); }
            c.drawText(nombre, xt, yb, texto);
            if (i < d.marcados.size() && d.marcados.get(i)) {
                float cx0 = col == 0 ? cols[1] : cols[3], cx1 = col == 0 ? cols[2] : cols[4];
                fuente(15f, true);
                centrado(c, "X", cx0, cx1, filaY0 + fila * alto + 17.3f);
            }
        }

        // --- Documentación ---
        caja(c, 450.1f, 525.9f);
        parrafo(c, TEXTO_DOCUMENTACION, 475.9f);

        // --- Declaración ---
        caja(c, 525.9f, 646.5f);
        float y = parrafo(c, TEXTO_DECLARO, 559.6f);
        fuente(T, false);
        c.drawText(TEXTO_CONSTE, TX0, y + 29.1f, texto);

        // --- Firma ---
        caja(c, 646.5f, 764.4f);
        fuente(T, false);
        c.drawText("Firma", 88.8f, 660.3f, texto);
        if (d.firma != null) {
            RectF hueco = new RectF(130, 664, 540, 744);
            float esc = Math.min(hueco.width() / d.firma.getWidth(), hueco.height() / d.firma.getHeight());
            float w = d.firma.getWidth() * esc, h = d.firma.getHeight() * esc;
            float fx = hueco.left + (hueco.width() - w) / 2, fy = hueco.top + (hueco.height() - h) / 2;
            c.drawBitmap(d.firma, new Rect(0, 0, d.firma.getWidth(), d.firma.getHeight()),
                    new RectF(fx, fy, fx + w, fy + h), texto);
        }
        fuente(12f, false);
        c.drawText("El trabajador D.", 88.8f, 761.1f, texto);
        c.drawLine(173f, 760.8f, 425f, 760.8f, linea);
        c.drawText("Fecha", 437.5f, 761.1f, texto);
        fuente(10f, false);
        c.drawText(":", 466.1f, 760.6f, texto);
        c.drawLine(479f, 760.8f, 552f, 760.8f, linea);
        tam = 12f;
        fuente(tam, false);
        while (tam > 7 && texto.measureText(d.nombre) > 246) { tam -= 0.25f; fuente(tam, false); }
        c.drawText(d.nombre, 176f, 758f, texto);
        fuente(12f, false);
        centrado(c, d.fecha, 479f, 552f, 758f);

        pie(c);
    }

    // ======================================================================
    // Cara 2: normas UNE (fija)
    // ======================================================================
    public void dibujarReverso(Canvas c) {
        cabecera(c, "NORMAS UNE Y CATEGORIAS DE REFERENCIA APLICABLES");
        caja(c, 112.3f, 188.1f);
        parrafo(c, TEXTO_DORSO, 138.1f);

        float[] cols = {X0, 227.6f, 482.6f, X1};
        float y = 188.1f;
        fuente(12f, false);
        centrado(c, "EPI", cols[0], cols[1], 202.9f);
        centrado(c, "NORMA UNE", cols[1], cols[2], 202.9f);
        centrado(c, "CATEGORIA", cols[2], cols[3], 202.9f);
        filaTabla(c, cols, y, 209.2f);
        y = 209.2f;

        for (String[] f : NORMAS) {
            fuente(T, false);
            List<String> a = partir(f[0], cols[1] - cols[0] - 4);
            List<String> b = new ArrayList<>();
            String[] trozos = f[1].split("\n");
            for (String trozo : trozos) b.addAll(partir(trozo, cols[2] - cols[1] - 3));
            float pasoB = trozos.length > 1 ? 20.1f : INTERL;  // dos normas separadas, como en el Word
            float hA = (a.size() - 1) * INTERL, hB = (b.size() - 1) * pasoB;
            float h = 23.6f + Math.max(hA, hB);
            float ba = y + (h - hA) / 2 + 5f;
            for (int i = 0; i < a.size(); i++) c.drawText(a.get(i), 86f, ba + i * INTERL, texto);
            float bb = y + (h - hB) / 2 + 5f;
            for (int i = 0; i < b.size(); i++) centrado(c, b.get(i), cols[1], cols[2], bb + i * pasoB);
            centrado(c, f[2], cols[2], cols[3], y + h / 2 + 5f);
            filaTabla(c, cols, y, y + h);
            y += h;
        }
        pie(c);
    }

    // ======================================================================
    // Piezas comunes
    // ======================================================================
    private void cabecera(Canvas c, String titulo) {
        caja(c, 57.1f, 112.3f);
        c.drawLine(LOGO_DER, 57.1f, LOGO_DER, 112.3f, linea);
        if (logo != null) {
            float w = 84.75f, h = w * logo.getHeight() / logo.getWidth();
            float lx = (X0 + LOGO_DER - w) / 2, ly = (57.1f + 112.3f - h) / 2;
            c.drawBitmap(logo, new Rect(0, 0, logo.getWidth(), logo.getHeight()), new RectF(lx, ly, lx + w, ly + h), texto);
        }
        fuente(T, true);
        centrado(c, titulo, LOGO_DER, X1, 89.7f);
    }

    private void pie(Canvas c) {
        fuente(8f, false);
        c.drawText(PIE, 560f - texto.measureText(PIE), 799.5f, texto);
    }

    private void caja(Canvas c, float y0, float y1) {
        c.drawRect(X0, y0, X1, y1, linea);
    }

    private void filaTabla(Canvas c, float[] cols, float y0, float y1) {
        c.drawRect(cols[0], y0, cols[cols.length - 1], y1, linea);
        for (int i = 1; i < cols.length - 1; i++) c.drawLine(cols[i], y0, cols[i], y1, linea);
    }

    private void fuente(float tam, boolean enNegrita) {
        texto.setTextSize(tam);
        texto.setTypeface(enNegrita ? negrita : normal);
    }

    private void centrado(Canvas c, String s, float xa, float xb, float yb) {
        c.drawText(s, (xa + xb - texto.measureText(s)) / 2, yb, texto);
    }

    private List<String> partir(String s, float ancho) {
        List<String> lineas = new ArrayList<>();
        StringBuilder actual = new StringBuilder();
        for (String palabra : s.split(" ")) {
            if (palabra.isEmpty()) continue;
            String prueba = actual.length() == 0 ? palabra : actual + " " + palabra;
            if (texto.measureText(prueba) <= ancho || actual.length() == 0) {
                actual.setLength(0);
                actual.append(prueba);
            } else {
                lineas.add(actual.toString());
                actual.setLength(0);
                actual.append(palabra);
            }
        }
        if (actual.length() > 0) lineas.add(actual.toString());
        return lineas;
    }

    /** Párrafo justificado. Devuelve la línea base de la última línea. */
    private float parrafo(Canvas c, String s, float yb) {
        float xa = TX0, xb = TX1, interl = INTERL;
        fuente(T, false);
        List<String> lineas = partir(s, xb - xa);
        float y = yb;
        for (int i = 0; i < lineas.size(); i++) {
            y = yb + i * interl;
            String l = lineas.get(i);
            String[] pal = l.split(" ");
            if (i == lineas.size() - 1 || pal.length == 1) {
                c.drawText(l, xa, y, texto);
                continue;
            }
            float suma = 0;
            for (String p : pal) suma += texto.measureText(p);
            float hueco = (xb - xa - suma) / (pal.length - 1);
            float x = xa;
            for (String p : pal) {
                c.drawText(p, x, y, texto);
                x += texto.measureText(p) + hueco;
            }
        }
        return y;
    }
}
